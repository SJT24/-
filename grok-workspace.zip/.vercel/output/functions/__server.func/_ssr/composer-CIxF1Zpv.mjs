import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, i as useQueryClient, o as require_react, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { C as useNavigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as cn } from "./utils-DAIVonyv.mjs";
import { a as useCurrentUser, i as UserMark, n as Input, t as Button } from "./use-current-user-BLNQxUcj.mjs";
import { c as Send, g as Cpu, v as CodeXml } from "../_libs/lucide-react.mjs";
import { a as Textarea, c as createPost, i as SignedOut, r as SignedIn } from "./shell-BRQglFHi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/composer-CIxF1Zpv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SNIPPET = `\`\`\`py
import torch
def message_pass(x, adj):
    return adj @ x
\`\`\``;
function Composer({ compact = false }) {
	const user = useCurrentUser();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const [body, setBody] = (0, import_react.useState)("");
	const [place, setPlace] = (0, import_react.useState)("");
	const mut = useMutation({
		mutationFn: () => createPost({ data: {
			body: body.trim(),
			imageKey: null,
			place: place.trim()
		} }),
		onSuccess: async () => {
			toast.success("神经元已发射");
			setBody("");
			setPlace("");
			await qc.invalidateQueries();
		},
		onError: (err) => {
			if (err instanceof Error && err.message === "Unauthorized") {
				navigate({ to: "/login" });
				return;
			}
			toast.error(err instanceof Error ? err.message : "发射失败");
		}
	});
	const remaining = 1200 - body.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-line bg-surface p-4 shadow-soft",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "接入节点后即可向神经网络发射动态。"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/login",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					children: "接入"
				})
			})]
		}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserMark, {
				name: user?.displayName ?? "节",
				hue: 140,
				size: compact ? "sm" : "md"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "min-w-0 flex-1 space-y-3",
				onSubmit: (e) => {
					e.preventDefault();
					if (!body.trim()) {
						toast.error("写一句再发射");
						return;
					}
					mut.mutate();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: body,
						onChange: (e) => setBody(e.target.value.slice(0, 1200)),
						placeholder: "发布研究灵感、架构图谱或代码片段… 可 @ResearchBot",
						className: cn("min-h-24", compact && "min-h-20")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: place,
						onChange: (e) => setPlace(e.target.value.slice(0, 40)),
						placeholder: "图谱 / 实验室（可空） 例如 GNN Lab",
						className: "h-10"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setBody((b) => b.includes("```") ? b : `${b}\n${SNIPPET}`.trim()),
									className: "inline-flex size-10 items-center justify-center rounded-md text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-neon",
									"aria-label": "插入代码片段",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CodeXml, {
										className: "size-4",
										strokeWidth: 1.75
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setPlace((p) => p || "共创舱 · 联合调试"),
									className: "inline-flex size-10 items-center justify-center rounded-md text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-volt",
									"aria-label": "标记共创舱",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cpu, {
										className: "size-4",
										strokeWidth: 1.75
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: cn("px-2 font-mono text-xs tabular-nums text-faint", remaining < 40 && "text-danger"),
									children: remaining
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "submit",
							size: "sm",
							disabled: mut.isPending,
							children: [mut.isPending ? "发射中…" : "发射神经元", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Send, {
								className: "size-3.5",
								strokeWidth: 2
							})]
						})]
					})
				]
			})]
		}) })]
	});
}
//#endregion
export { Composer as t };
