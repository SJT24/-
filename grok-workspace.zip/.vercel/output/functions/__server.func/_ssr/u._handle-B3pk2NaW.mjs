import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, o as require_react, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { C as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useCurrentUser, i as UserMark, n as Input, t as Button } from "./use-current-user-BLNQxUcj.mjs";
import { g as Cpu } from "../_libs/lucide-react.mjs";
import { a as Textarea, b as updateProfile, d as getProfile, g as listUserPosts, t as AppShell, v as toggleFollow } from "./shell-BRQglFHi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { n as Route$1 } from "./router-CtMX8Eau.mjs";
import { n as PostSkeleton, t as PostCard } from "./post-card-DjEM3Xxo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/u._handle-B3pk2NaW.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ProfilePage() {
	const { handle } = Route$1.useParams();
	const user = useCurrentUser();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const [editing, setEditing] = (0, import_react.useState)(false);
	const profile = useQuery({
		queryKey: ["profile", handle],
		queryFn: () => getProfile({ data: { handle } })
	});
	const posts = useQuery({
		queryKey: ["user-posts", profile.data?.userId],
		queryFn: () => listUserPosts({ data: { userId: profile.data.userId } }),
		enabled: Boolean(profile.data?.userId)
	});
	const followMut = useMutation({
		mutationFn: () => toggleFollow({ data: { userId: profile.data.userId } }),
		onSuccess: () => void qc.invalidateQueries(),
		onError: (err) => {
			if (err instanceof Error && err.message === "Unauthorized") navigate({ to: "/login" });
		}
	});
	const p = profile.data;
	const level = p ? Math.min(9, 1 + Math.floor(p.postCount / 2) + Math.floor(p.followerCount / 3)) : 1;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl",
		children: [
			profile.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-xl bg-surface-2" }) : null,
			profile.isSuccess && !p ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "py-16 text-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xl font-semibold",
					children: "没有这个节点"
				})
			}) : null,
			p ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative overflow-hidden rounded-xl border border-line bg-surface p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col items-center gap-4 sm:flex-row sm:items-start sm:gap-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserMark, {
							name: p.displayName,
							hue: p.hue,
							size: "lg"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1 text-center sm:text-left",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex flex-wrap items-center justify-center gap-2 sm:justify-start",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
										className: "text-xl font-bold",
										children: p.displayName
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "rounded border border-line bg-neon/10 px-2 py-0.5 font-mono text-xs text-neon",
										children: [
											"Lv.",
											level,
											" 节点"
										]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 font-mono text-xs text-faint",
									children: [
										"量子档案 @",
										p.handle,
										p.location ? ` · ${p.location}` : ""
									]
								}),
								p.bio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm leading-relaxed text-muted",
									children: p.bio
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
									className: "mt-5 flex flex-wrap justify-center gap-3 sm:justify-start",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											n: p.postCount,
											label: "发射节点"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											n: p.followerCount,
											label: "接入节点"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
											n: p.followingCount,
											label: "已连接"
										})
									]
								})
							]
						}),
						p.isMe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "outline",
							size: "sm",
							onClick: () => setEditing((v) => !v),
							children: editing ? "收起" : "编辑档案"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: p.following ? "outline" : "primary",
							size: "sm",
							onClick: () => followMut.mutate(),
							children: p.following ? "已连接" : "接入"
						})
					]
				}), editing && p.isMe ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditForm, {
					displayName: p.displayName,
					bio: p.bio,
					location: p.location,
					onDone: () => {
						setEditing(false);
						qc.invalidateQueries({ queryKey: ["profile", handle] });
					}
				}) : null]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 space-y-4",
				children: [
					posts.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostSkeleton, {}) : null,
					posts.data?.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-10 text-center text-sm text-muted",
						children: user?.id === p?.userId ? "还没有发射。去写一段神经元吧。" : "这个节点还很安静。"
					}) : null,
					posts.data?.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, { post }, post.id))
				]
			})
		]
	}) });
}
function Stat({ n, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-bg px-3 py-1.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
			className: "font-mono text-xs text-faint",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
			className: "font-mono text-sm font-semibold tabular-nums text-neon",
			children: n
		})]
	});
}
function EditForm({ displayName, bio, location, onDone }) {
	const [name, setName] = (0, import_react.useState)(displayName);
	const [b, setB] = (0, import_react.useState)(bio);
	const [loc, setLoc] = (0, import_react.useState)(location);
	const mut = useMutation({
		mutationFn: () => updateProfile({ data: {
			displayName: name,
			bio: b,
			location: loc
		} }),
		onSuccess: () => {
			toast.success("档案已同步");
			onDone();
		},
		onError: () => toast.error("没能保存")
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
		className: "mt-6 space-y-3 border-t border-line pt-5",
		onSubmit: (e) => {
			e.preventDefault();
			mut.mutate();
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: name,
				onChange: (e) => setName(e.target.value),
				maxLength: 24
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: loc,
				onChange: (e) => setLoc(e.target.value),
				placeholder: "实验室",
				maxLength: 24
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				value: b,
				onChange: (e) => setB(e.target.value),
				placeholder: "一句话介绍",
				maxLength: 120,
				className: "min-h-24"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "submit",
				disabled: mut.isPending,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Cpu, { className: "size-3.5" }), "保存"]
			})
		]
	});
}
//#endregion
export { ProfilePage as component };
