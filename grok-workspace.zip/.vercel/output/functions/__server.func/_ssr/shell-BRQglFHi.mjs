import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, n as useQuery, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { C as useNavigate, S as Navigate, m as useRouterState, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { Ft as string, Mt as object, jt as number, wt as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { i as signOut } from "./client-1vAx-gM_.mjs";
import { r as cn } from "./utils-DAIVonyv.mjs";
import { a as useCurrentUser, i as UserMark, n as Input, o as useCurrentUserState, r as NeuralMark, t as Button } from "./use-current-user-BLNQxUcj.mjs";
import { a as hasGateSessionMarker } from "./server-SWSTtgxV.mjs";
import { n as optionalAuth, t as authMiddleware } from "./optional-auth-BhJiqXVy.mjs";
import { _ as Compass, b as Bell, d as PenLine, f as Network, g as Cpu, l as Search, m as Menu, n as X, o as Terminal, r as UserRound, t as Zap } from "../_libs/lucide-react.mjs";
import { t as create } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/shell-BRQglFHi.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Textarea = (0, import_react.forwardRef)(function Textarea({ className, ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		ref,
		className: cn("min-h-32 w-full rounded-lg border border-line bg-bg px-3.5 py-3 text-sm leading-relaxed text-fg placeholder:text-faint", "font-mono transition-[border-color,box-shadow] duration-150", "focus-visible:border-neon focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon/30", className),
		...props
	});
});
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var askResearchBot = createServerFn({ method: "POST" }).validator(object({
	prompt: string().min(1).max(800),
	context: string().max(240).optional()
})).handler(createSsrRpc("c638d06f5c020c13f21d4dbc6fc2f12e3f1dc33c24d8210f6c4c5ecf894ff9cb"));
function ResearchBotBox() {
	const [prompt, setPrompt] = (0, import_react.useState)("");
	const [reply, setReply] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function onSubmit(e) {
		e.preventDefault();
		const text = prompt.trim();
		if (!text || busy) return;
		setBusy(true);
		setError(null);
		try {
			const res = await askResearchBot({ data: { prompt: text } });
			if (res.ok) {
				setReply(res.text);
				setPrompt("");
			} else setError(res.error);
		} catch {
			setError("无法连接 ResearchBot");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative overflow-hidden rounded-xl border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-3 flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex items-center gap-1.5 font-mono text-xs font-semibold text-volt",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Terminal, {
						className: "size-3.5",
						strokeWidth: 2
					}), "ResearchBot 快速调用"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "font-mono text-xs text-faint",
					children: "AI Agent"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit,
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
					value: prompt,
					onChange: (e) => setPrompt(e.target.value.slice(0, 800)),
					rows: 3,
					placeholder: "向 ResearchBot 提问 GNN、对齐，或请求生成代码片…",
					className: "min-h-20"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-mono text-xs text-faint",
						children: "Markdown / Python"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "submit",
						size: "sm",
						disabled: busy || !prompt.trim(),
						children: [busy ? "推理中…" : "发送指令", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Zap, {
							className: "size-3.5",
							strokeWidth: 2
						})]
					})]
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 rounded-md border border-line bg-bg px-3 py-2 font-mono text-xs text-danger",
				children: error
			}) : null,
			reply ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
				className: "mt-3 max-h-48 overflow-y-auto whitespace-pre-wrap rounded-md border border-line bg-bg px-3 py-2 font-mono text-xs leading-relaxed text-neon",
				children: reply
			}) : null
		]
	});
}
var subscribeToNothing = () => () => {};
var noGateSessionOnServer = () => false;
/**
* Auth state components — plain wrappers around `useCurrentUserState()`.
*
* With auth on, visitors are signed out until they authenticate — in the sandbox
* live preview too, which does real sign-in. The shared dev user appears only
* when auth is disabled (`VITE_AUTH_ENABLED=false`, the shipped default).
* While the session is still resolving, gates that care about signed-out state
* render nothing so there's no signed-out flash on hard reload.
*/
/** Where `RedirectToSignIn` sends signed-out visitors. Create this route. */
var SIGN_IN_PATH = "/login";
/** Render children only when a user is present (real session, or the disabled-auth dev user). */
function SignedIn({ children }) {
	const { user } = useCurrentUserState();
	return user ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children }) : null;
}
/**
* Render children only once we KNOW the visitor is signed out (`isPending` has
* cleared and there is no user). Hidden while the session is still loading.
*/
function SignedOut({ children }) {
	const { user, isPending } = useCurrentUserState();
	if (isPending || user) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
/**
* Client-side redirect to the sign-in route (TanStack `<Navigate>` — NOT a full
* `window.location` reload). A hard navigation re-bootstraps the SPA and re-runs
* session loading, which feels like a second "Loading…" on /login.
*
* Guard routes by waiting out `isPending` first (see `use-current-user`), then
* render this.
*/
function RedirectToSignIn({ to = SIGN_IN_PATH }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to });
}
/**
* Minimal signed-in identity chip + sign-out. Restyle freely (see the
* `design-ui` skill). Sign-out is only shown when auth is enabled (the
* disabled-auth dev user has nothing to sign out of) and the session is not
* gate-materialized — behind the gate the next request signs the viewer
* straight back in, so a sign-out control there is a broken loop.
*/
function UserButton() {
	const user = useCurrentUser();
	const [signingOut, setSigningOut] = (0, import_react.useState)(false);
	const gateSession = (0, import_react.useSyncExternalStore)(subscribeToNothing, hasGateSessionMarker, noGateSessionOnServer);
	if (!user) return null;
	const label = user.displayName ?? user.primaryEmail ?? "Account";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-center gap-2",
		children: [
			user.profileImageUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: user.profileImageUrl,
				alt: "",
				className: "h-8 w-8 rounded-full object-cover"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "grid h-8 w-8 place-items-center rounded-full bg-black/10 text-sm font-medium dark:bg-white/20",
				children: label.charAt(0).toUpperCase()
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-sm font-medium",
				children: label
			}),
			!gateSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				disabled: signingOut,
				onClick: () => {
					setSigningOut(true);
					signOut().catch(() => setSigningOut(false));
				},
				className: "cursor-pointer text-sm underline-offset-4 opacity-70 hover:underline disabled:cursor-wait disabled:no-underline",
				children: signingOut ? "Signing out…" : "Sign out"
			})
		]
	});
}
var ensureProfile = createServerFn({ method: "POST" }).validator(object({ displayName: string().max(40).optional() })).middleware([authMiddleware]).handler(createSsrRpc("665de9c19cf22f399ae34632b84f04240c9439f52cd766a0c6eeca9ae0e75a79"));
var listFeed = createServerFn({ method: "GET" }).validator(object({ tab: _enum(["discover", "following"]) })).middleware([optionalAuth]).handler(createSsrRpc("4f02c05cfec80f11671eedf5d3a29af13507f045aaa35af52f111c9a77ba4b39"));
var getPost = createServerFn({ method: "GET" }).validator(object({ id: number() })).middleware([optionalAuth]).handler(createSsrRpc("1c49668ea41268fc8d5dc7da6cb787b8e4db65aa75fc20db0a12f6ca6ae04e8a"));
var listComments = createServerFn({ method: "GET" }).validator(object({ postId: number() })).handler(createSsrRpc("300b39690af2b776d1a7efa268737e3423c32a536e658243efd7d6c6672e4067"));
var createPost = createServerFn({ method: "POST" }).validator(object({
	body: string().min(1).max(1200),
	imageKey: string().nullable(),
	place: string().max(40)
})).middleware([authMiddleware]).handler(createSsrRpc("2e046f629e0a951555b8a8dccad4b150f583186b75d4e32a38c63833b7027faf"));
var deletePost = createServerFn({ method: "POST" }).validator(object({ id: number() })).middleware([authMiddleware]).handler(createSsrRpc("17e57f89d2339fb72fad1f4ef2f64e41ce18f4a2fb3f02ce367d0243ddf99b84"));
var toggleLike = createServerFn({ method: "POST" }).validator(object({ postId: number() })).middleware([authMiddleware]).handler(createSsrRpc("01110e494549161e240e643d8b313f1465fa67b7cb84dc2ab2724447ae26e0fe"));
var addComment = createServerFn({ method: "POST" }).validator(object({
	postId: number(),
	body: string().min(1).max(280)
})).middleware([authMiddleware]).handler(createSsrRpc("831f5dd016321dca2d89f4c23834aa44038cf1be17ee18162cb25e878098c8f1"));
var toggleFollow = createServerFn({ method: "POST" }).validator(object({ userId: string().min(1) })).middleware([authMiddleware]).handler(createSsrRpc("53ae5660dd088d9ef0507d5e5a2901fdea09dd4126abeb11caf021eb0ad4d848"));
var getProfile = createServerFn({ method: "GET" }).validator(object({ handle: string().min(1).max(32) })).middleware([optionalAuth]).handler(createSsrRpc("90770bdeff735883284f14b7f5f7bc81a48f6fe56d46e06f9b976c0f6ac57bb4"));
var listUserPosts = createServerFn({ method: "GET" }).validator(object({ userId: string().min(1) })).middleware([optionalAuth]).handler(createSsrRpc("71869761a89f4aa6eccb9bf35e147db792f5989a445953f1645318d00ffa4d87"));
var updateProfile = createServerFn({ method: "POST" }).validator(object({
	displayName: string().min(1).max(24),
	bio: string().max(120),
	location: string().max(24)
})).middleware([authMiddleware]).handler(createSsrRpc("15d11417faffd91cf4b812bf89a98d8046960f7c7c3608871d20400f7d207878"));
var listPeople = createServerFn({ method: "GET" }).validator(object({ q: string().max(40).optional() })).middleware([optionalAuth]).handler(createSsrRpc("78123baf1821fcdea736903ac1b59490f05fbb62ef942e27c6f21e5e8cbb1ad0"));
var listNotifications = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("71cfd6dde135218fc7b68aa73e8adc7e1245c946498a778cb7605158a0898638"));
var unreadCount = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("0bb479efde4620b78cfd92627f84d612743295ea11f5f91e792b3ce3184cedca"));
var markRead = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(createSsrRpc("893f6ebedd1ab518a97dd8de382c04eba04579dc6a70388bb672753e98d581d2"));
var myProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("d6bd68a704f1992e29151d47b6aaf783020de09bf4528edbaa96faeda2ded1f4"));
var clusterStats = createServerFn({ method: "GET" }).handler(createSsrRpc("89e4de22b23dd7e1aa5226d211044fdce261b640efda8e3b82cf10797cf5ea78"));
var SEED_PODS = [
	{
		id: "POD-8801",
		title: "向量数据库与图神经网络加速",
		summary: "多 Agent 协同优化高维向量检索速度，已集成 ResearchBot 与 CodeAgent 双引擎自动生成测试用例。",
		status: "live",
		statusLabel: "实时调试中",
		progress: 84,
		researchers: 8,
		agents: 2
	},
	{
		id: "POD-8802",
		title: "极客视觉 VI 与电路板神经元生成",
		summary: "探索黑客绿与电光黄美学极限，结合 SVG 与神经网络图腾实时渲染品牌视觉与交互界面。",
		status: "render",
		statusLabel: "多模态渲染",
		progress: 92,
		researchers: 12,
		agents: 3
	},
	{
		id: "POD-8803",
		title: "大模型对齐与去中心化评测",
		summary: "把对齐评测拆成可验证的节点任务。每个研究员提交一条对抗样本，集群汇总漂移曲线。",
		status: "live",
		statusLabel: "联合评测",
		progress: 61,
		researchers: 19,
		agents: 4
	},
	{
		id: "POD-8804",
		title: "量子密码学与模型防御机制",
		summary: "在权重分发层加入可验证随机数与差分隐私噪声，防止共创舱模型被梯度反演。",
		status: "idle",
		statusLabel: "等待接入",
		progress: 37,
		researchers: 6,
		agents: 2
	}
];
var usePodStore = create((set, get) => ({
	pods: SEED_PODS,
	addPod: ({ title, summary }) => {
		const pod = {
			id: `POD-${8800 + get().pods.length + 1}`,
			title,
			summary,
			status: "live",
			statusLabel: "刚刚点燃",
			progress: 8,
			researchers: 1,
			agents: 1
		};
		set({ pods: [pod, ...get().pods] });
		return pod;
	}
}));
var NAV = [
	{
		to: "/",
		label: "神经网络",
		icon: Network,
		match: (p) => p === "/"
	},
	{
		to: "/pods",
		label: "AI 共创舱",
		icon: Cpu,
		match: (p) => p.startsWith("/pods")
	},
	{
		to: "/explore",
		label: "节点图谱",
		icon: Compass,
		match: (p) => p.startsWith("/explore")
	},
	{
		to: "/notifications",
		label: "突触通知",
		icon: Bell,
		match: (p) => p.startsWith("/notifications")
	}
];
function AppShell({ children, aside }) {
	const { user, isPending } = useCurrentUserState();
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const [handle, setHandle] = (0, import_react.useState)(null);
	const [drawer, setDrawer] = (0, import_react.useState)(false);
	const [q, setQ] = (0, import_react.useState)("");
	const navigate = useNavigate();
	const livePods = usePodStore((s) => s.pods.filter((p) => p.status !== "idle").length);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		let alive = true;
		ensureProfile({ data: { displayName: user.displayName ?? void 0 } }).then((r) => {
			if (alive) setHandle(r.handle);
		}).catch(() => void 0);
		return () => {
			alive = false;
		};
	}, [user]);
	(0, import_react.useEffect)(() => {
		function onKey(e) {
			if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
				e.preventDefault();
				const el = document.getElementById("global-search");
				if (el) el.focus();
				else navigate({ to: "/explore" });
			}
		}
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [navigate]);
	const unread = useQuery({
		queryKey: ["unread"],
		queryFn: () => unreadCount(),
		enabled: Boolean(user),
		refetchInterval: 3e4
	});
	const stats = useQuery({
		queryKey: ["cluster-stats"],
		queryFn: () => clusterStats()
	});
	function submitSearch(e) {
		e.preventDefault();
		navigate({
			to: "/explore",
			search: { q: q.trim() }
		});
		setDrawer(false);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-grid min-h-dvh",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-40 border-b border-line bg-surface/90 backdrop-blur-md",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 lg:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "inline-flex size-11 items-center justify-center rounded-md border border-line bg-bg text-muted lg:hidden",
							onClick: () => setDrawer(true),
							"aria-label": "打开导航",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {
								className: "size-4",
								strokeWidth: 1.8
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
							onSubmit: submitSearch,
							className: "mx-auto hidden min-w-0 flex-1 items-center md:flex md:max-w-md lg:max-w-lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex h-11 w-full items-center gap-2 rounded-full border border-line bg-bg px-4 focus-within:border-neon",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, {
										className: "size-3.5 shrink-0 text-faint",
										strokeWidth: 1.8
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										id: "global-search",
										value: q,
										onChange: (e) => setQ(e.target.value),
										placeholder: "搜索节点、Agent 或代码图谱…",
										className: "min-w-0 flex-1 bg-transparent font-mono text-xs text-fg outline-none placeholder:text-faint"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden rounded border border-line bg-surface-2 px-1.5 py-0.5 font-mono text-xs text-neon sm:inline",
										children: "⌘K"
									})
								]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "ml-auto flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "hidden items-center gap-2 rounded-full border border-line bg-surface-2 px-3 py-1 font-mono text-xs xl:flex",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 rounded-full bg-neon" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-neon",
										children: "ResearchBot v4.2 协同中"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
									to: "/notifications",
									className: "relative inline-flex size-11 items-center justify-center rounded-md border border-line bg-bg text-muted hover:text-neon",
									"aria-label": "通知",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
										className: "size-4",
										strokeWidth: 1.8
									}), unread.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-2 right-2 size-2 rounded-full bg-volt" }) : null]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/login",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										children: "接入"
									})
								}) }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => {
										if (handle) navigate({
											to: "/u/$handle",
											params: { handle }
										});
									},
									className: "flex items-center gap-2 border-l border-line pl-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserMark, {
										name: user?.displayName ?? "节",
										hue: 140,
										size: "sm"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "hidden text-left sm:block",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block text-xs font-semibold text-fg",
											children: user?.displayName ?? "节点"
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "block font-mono text-xs text-neon",
											children: handle ? `@${handle}` : "量子档案"
										})]
									})]
								}) })
							]
						})
					]
				})
			}),
			drawer ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "fixed inset-0 z-50 lg:hidden",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "absolute inset-0 bg-hero-ink/80",
					"aria-label": "关闭导航",
					onClick: () => setDrawer(false)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative flex h-full w-72 flex-col border-r border-line bg-surface p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-5 flex items-center justify-between border-b border-line pb-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brand, { compact: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "inline-flex size-11 items-center justify-center text-muted",
								onClick: () => setDrawer(false),
								"aria-label": "关闭",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("form", {
							onSubmit: submitSearch,
							className: "mb-4",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: q,
								onChange: (e) => setQ(e.target.value),
								placeholder: "搜索节点…",
								"aria-label": "搜索"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "flex flex-1 flex-col gap-1",
							children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: item.to,
								onClick: () => setDrawer(false),
								className: cn("flex h-11 items-center gap-3 rounded-lg px-3 text-sm", item.match(pathname) ? "border border-line bg-neon/10 text-neon" : "text-muted hover:bg-surface-2 hover:text-neon"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
									className: "size-4",
									strokeWidth: 1.8
								}), item.label]
							}, item.to))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "border-t border-line pt-4 font-mono text-xs text-faint",
							children: "ShanJiTong v2.6 · Neural Ecosystem"
						})
					]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto grid max-w-7xl grid-cols-1 gap-6 px-4 py-6 lg:grid-cols-12 lg:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "hidden space-y-4 lg:col-span-3 lg:block",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "glow-live rounded-xl border border-line bg-surface p-4 shadow-soft",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mb-3 px-3 font-mono text-xs uppercase tracking-wider text-faint",
								children: "核心路由"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
								className: "space-y-1",
								children: [
									NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLink, {
										to: item.to,
										label: item.label,
										icon: item.icon,
										active: item.match(pathname),
										badge: item.to === "/notifications" ? unread.data : item.to === "/pods" ? livePods : void 0,
										badgeTone: item.to === "/pods" ? "volt" : "neon"
									}, item.to)),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeLink, {
										handle,
										active: pathname.startsWith("/u/")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/compose",
										className: "mt-3 block",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
											className: "w-full",
											size: "lg",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, {
												className: "size-4",
												strokeWidth: 1.75
											}), "发射节点"]
										})
									}) })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResearchBotBox, {}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3 rounded-xl border border-line bg-surface p-4 text-xs",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "font-mono text-xs uppercase tracking-wider text-faint",
									children: "集群运行状态"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between font-mono",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: "活跃神经网络节点"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold tabular-nums text-neon",
										children: (stats.data?.nodes ?? 0).toLocaleString()
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between font-mono",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: "已发射神经元"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold tabular-nums text-volt",
										children: (stats.data?.sparks ?? 0).toLocaleString()
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between font-mono",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-muted",
										children: "突触讨论"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-bold tabular-nums text-fg",
										children: (stats.data?.links ?? 0).toLocaleString()
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-1 h-1.5 overflow-hidden rounded-full border border-line bg-bg",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "bg-signal h-full w-4/5" })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthCorner, {
							handle,
							pending: isPending
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "min-w-0 lg:col-span-9",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex min-w-0 gap-6 pb-20 lg:pb-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
							className: "min-w-0 flex-1",
							children
						}), aside ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
							className: "sticky top-24 hidden h-[calc(100dvh-7rem)] w-72 shrink-0 overflow-y-auto xl:block",
							children: aside
						}) : null]
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-line bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm lg:hidden",
				children: [
					NAV.slice(0, 3).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: item.to,
						className: cn("relative flex h-14 flex-col items-center justify-center gap-0.5 text-xs", item.match(pathname) ? "text-neon" : "text-muted"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, {
							className: "size-5",
							strokeWidth: 1.7
						}), item.label.replace("神经网络", "动态").replace("AI 共创舱", "共创舱").replace("节点图谱", "图谱")]
					}, item.to)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/notifications",
						className: cn("relative flex h-14 flex-col items-center justify-center gap-0.5 text-xs", pathname.startsWith("/notifications") ? "text-neon" : "text-muted"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, {
								className: "size-5",
								strokeWidth: 1.7
							}),
							"通知",
							unread.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute top-1.5 right-6 size-1.5 rounded-full bg-volt" }) : null
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MeLink, {
						handle,
						active: pathname.startsWith("/u/"),
						mobile: true
					})
				]
			})
		]
	});
}
function Brand({ compact = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: "flex items-center gap-2.5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeuralMark, { className: "size-10" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "min-w-0",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-signal block text-sm font-bold tracking-wider",
				children: "SHAN JI TONG"
			}), compact ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "hidden font-mono text-xs tracking-widest text-faint uppercase sm:block",
				children: "善鸡通 · 神经网络社群"
			})]
		})]
	});
}
function NavLink({ to, label, icon: Icon, active, badge, badgeTone = "neon" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("relative flex h-11 items-center gap-3 rounded-lg px-3 text-sm transition-colors duration-150", active ? "border border-line bg-neon/10 font-semibold text-neon" : "text-muted hover:bg-surface-2 hover:text-neon"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, {
				className: "size-4",
				strokeWidth: 1.7
			}),
			label,
			badge ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: cn("ml-auto rounded px-1.5 py-0.5 font-mono text-xs", badgeTone === "volt" ? "bg-volt/15 text-volt" : "size-2 rounded-full bg-neon p-0"),
				children: badgeTone === "volt" ? `${badge} 活跃` : null
			}) : null
		]
	});
}
function MeLink({ handle, active, mobile = false }) {
	if (!useCurrentUser()) {
		if (mobile) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/login",
			className: "flex h-14 flex-col items-center justify-center gap-0.5 text-xs text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {
				className: "size-5",
				strokeWidth: 1.7
			}), "档案"]
		});
		return null;
	}
	if (mobile) {
		if (!handle) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/login",
			className: "flex h-14 flex-col items-center justify-center gap-0.5 text-xs text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {
				className: "size-5",
				strokeWidth: 1.7
			}), "档案"]
		});
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
			to: "/u/$handle",
			params: { handle },
			className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-xs", active ? "text-neon" : "text-muted"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {
				className: "size-5",
				strokeWidth: 1.7
			}), "档案"]
		});
	}
	if (!handle) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "flex h-11 items-center gap-3 rounded-lg px-3 text-sm text-muted",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {
			className: "size-4",
			strokeWidth: 1.7
		}), "量子档案"]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/u/$handle",
		params: { handle },
		className: cn("flex h-11 items-center gap-3 rounded-lg px-3 text-sm transition-colors duration-150", active ? "border border-line bg-neon/10 font-semibold text-neon" : "text-muted hover:bg-surface-2 hover:text-neon"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserRound, {
			className: "size-4",
			strokeWidth: 1.7
		}), "量子档案"]
	});
}
function AuthCorner({ handle, pending }) {
	const user = useCurrentUser();
	const mine = useQuery({
		queryKey: ["me-profile"],
		queryFn: () => myProfile(),
		enabled: Boolean(user)
	});
	const shownHandle = handle ?? mine.data?.handle ?? null;
	if (pending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-12 w-full animate-pulse rounded-md bg-surface-2" });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/login",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			variant: "outline",
			className: "w-full",
			children: "接入善鸡通"
		})
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-lg border border-line bg-surface-2/60 p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserMark, {
				name: user.displayName ?? shownHandle ?? "节",
				hue: 140,
				size: "sm"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate text-sm font-medium",
					children: user.displayName ?? "节点"
				}), shownHandle ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "truncate font-mono text-xs text-faint",
					children: ["@", shownHandle]
				}) : null]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-2 text-xs text-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
		})]
	});
}
//#endregion
export { markRead as _, Textarea as a, updateProfile as b, createPost as c, getProfile as d, listComments as f, listUserPosts as g, listPeople as h, SignedOut as i, deletePost as l, listNotifications as m, RedirectToSignIn as n, addComment as o, listFeed as p, SignedIn as r, askResearchBot as s, AppShell as t, getPost as u, toggleFollow as v, usePodStore as x, toggleLike as y };
