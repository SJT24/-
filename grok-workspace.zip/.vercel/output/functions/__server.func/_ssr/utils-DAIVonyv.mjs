import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/utils-DAIVonyv.js
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function iso(value) {
	if (value instanceof Date) return value.toISOString();
	if (typeof value === "string") return value;
	return new Date(String(value)).toISOString();
}
function asInt(value) {
	const n = typeof value === "number" ? value : Number(value);
	return Number.isFinite(n) ? n : 0;
}
function asBool(value) {
	return value === true || value === "t" || value === "true";
}
//#endregion
export { iso as i, asInt as n, cn as r, asBool as t };
