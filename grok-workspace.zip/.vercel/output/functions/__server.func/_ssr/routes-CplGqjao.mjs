import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, n as useQuery, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as cn } from "./utils-DAIVonyv.mjs";
import { a as useCurrentUser } from "./use-current-user-BLNQxUcj.mjs";
import { h as listPeople, p as listFeed, t as AppShell } from "./shell-BRQglFHi.mjs";
import { t as Composer } from "./composer-CIxF1Zpv.mjs";
import { t as PersonRow } from "./people-DRljt2kB.mjs";
import { n as PostSkeleton, t as PostCard } from "./post-card-DjEM3Xxo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CplGqjao.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const user = useCurrentUser();
	const [tab, setTab] = (0, import_react.useState)("discover");
	const feed = useQuery({
		queryKey: ["feed", tab],
		queryFn: () => listFeed({ data: { tab } })
	});
	const suggested = (useQuery({
		queryKey: ["people-aside"],
		queryFn: () => listPeople({ data: {} })
	}).data ?? []).filter((p) => !p.following && p.userId !== user?.id).slice(0, 5);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {
		aside: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs uppercase tracking-wider text-faint",
						children: "推荐节点"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-1 text-sm font-semibold text-fg",
						children: "可接入的研究员"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-4 space-y-4",
						children: suggested.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonRow, {
							person: p,
							compact: true
						}, p.userId))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/explore",
						className: "mt-4 inline-block text-sm text-neon underline-offset-4 hover:underline",
						children: "打开完整图谱"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs leading-relaxed text-faint",
				children: "善鸡通是去中心化极客社群。动态是神经元，共创舱是突触，档案是量子身份。"
			})]
		}),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto max-w-2xl space-y-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rise-in flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-neon" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "text-base font-bold tracking-wide text-fg",
							children: "神经网络动态"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1 rounded-lg bg-bg p-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabButton, {
							active: tab === "discover",
							onClick: () => setTab("discover"),
							children: "全网图谱"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabButton, {
							active: tab === "following",
							onClick: () => setTab("following"),
							children: "已连接"
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "rise-in-2",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rise-in-3 space-y-4",
					children: [
						feed.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostSkeleton, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostSkeleton, {})] }) : null,
						feed.isError && !feed.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "rounded-xl border border-line px-5 py-8 text-center text-sm text-muted",
							children: "图谱暂时不可见。稍后重试。"
						}) : null,
						feed.data?.length === 0 && tab === "following" && !feed.isLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EmptyFollow, {}) : null,
						feed.data?.map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, { post }, post.id))
					]
				})
			]
		})
	});
}
function TabButton({ active, onClick, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: cn("h-10 rounded-md px-3 font-mono text-xs transition-colors duration-150", active ? "bg-surface-2 text-neon" : "text-muted hover:text-fg"),
		children
	});
}
function EmptyFollow() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-dashed border-line px-6 py-12 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-lg font-semibold text-fg",
				children: "连接还很安静"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "去节点图谱遇见研究员，动态会汇到这一边。"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/explore",
				className: "mt-4 inline-block text-sm font-medium text-neon underline-offset-4 hover:underline",
				children: "打开图谱"
			})
		]
	});
}
//#endregion
export { Home as component };
