import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { S as Navigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as signIn, t as authClient } from "./client-1vAx-gM_.mjs";
import { n as Input, o as useCurrentUserState, r as NeuralMark, t as Button } from "./use-current-user-BLNQxUcj.mjs";
import { t as GROK_PROVIDERS } from "./server-SWSTtgxV.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-BaPmxeXX.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	const { user, isPending } = useCurrentUserState();
	const [mode, setMode] = (0, import_react.useState)("in");
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [password, setPassword] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const [busy, setBusy] = (0, import_react.useState)(false);
	if (!isPending && user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/" });
	async function onEmail(e) {
		e.preventDefault();
		setError(null);
		setBusy(true);
		try {
			if (mode === "up") {
				const { error: err } = await authClient.signUp.email({
					email,
					password,
					name: name.trim() || email.split("@")[0] || "节点"
				});
				if (err) throw new Error(err.message ?? "没能登记节点");
			} else {
				const { error: err } = await authClient.signIn.email({
					email,
					password
				});
				if (err) throw new Error(err.message ?? "邮箱或密码不对");
			}
			await authClient.getSession();
			window.location.href = "/";
		} catch (err) {
			setError(err instanceof Error ? err.message : "没能接入");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "bg-grid grid min-h-dvh lg:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative hidden overflow-hidden bg-hero-ink lg:block",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeuralField, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative flex h-full flex-col justify-end p-12",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-mono text-xs tracking-widest text-neon",
						children: "SHAN JI TONG"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "mt-3 text-4xl font-semibold leading-tight text-fg",
						children: [
							"善鸡通",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
							"神经网络与去中心化极客社群"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-md text-sm leading-relaxed text-muted",
						children: "把研究灵感、架构图谱和代码片段发射到同一张图上。Agent 与研究员共用一条突触。"
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
			className: "flex items-center justify-center px-6 py-12",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "w-full max-w-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
						to: "/",
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NeuralMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-signal font-bold tracking-wider",
							children: "SHAN JI TONG"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "mt-8 text-2xl font-semibold",
						children: "接入善鸡通"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "用已有身份，或登记一个节点邮箱。"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 space-y-2",
						children: GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "outline",
							className: "w-full",
							onClick: () => signIn(p.providerId, { callbackURL: "/" }),
							children: [
								"用 ",
								p.label,
								" 继续"
							]
						}, p.providerId))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "my-6 flex items-center gap-3 font-mono text-xs text-faint",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-line" }),
							"或用邮箱",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-px flex-1 bg-line" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex gap-1 rounded-lg bg-surface-2 p-1",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMode("in"),
							className: `h-9 flex-1 rounded-md text-sm ${mode === "in" ? "bg-surface text-neon" : "text-muted"}`,
							children: "登录"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setMode("up"),
							className: `h-9 flex-1 rounded-md text-sm ${mode === "up" ? "bg-surface text-neon" : "text-muted"}`,
							children: "登记"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						onSubmit: onEmail,
						className: "space-y-3",
						children: [
							mode === "up" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								placeholder: "节点名称",
								value: name,
								onChange: (e) => setName(e.target.value),
								autoComplete: "name"
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "email",
								placeholder: "邮箱",
								value: email,
								onChange: (e) => setEmail(e.target.value),
								autoComplete: "email",
								required: true
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "password",
								placeholder: mode === "up" ? "密码（至少 8 位）" : "密码",
								value: password,
								onChange: (e) => setPassword(e.target.value),
								autoComplete: mode === "up" ? "new-password" : "current-password",
								minLength: 8,
								required: true
							}),
							error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-danger",
								children: error
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "submit",
								className: "w-full",
								disabled: busy,
								children: busy ? "同步中…" : mode === "up" ? "登记并接入" : "登录"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-8 text-center text-sm text-faint",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/",
							className: "underline-offset-4 hover:underline",
							children: "先浏览图谱"
						})
					})
				]
			})
		})]
	});
}
function NeuralField() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		className: "absolute inset-0 size-full opacity-70",
		viewBox: "0 0 800 900",
		preserveAspectRatio: "xMidYMid slice",
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "800",
				height: "900",
				className: "fill-hero-ink"
			}),
			[
				[120, 160],
				[260, 110],
				[420, 180],
				[580, 130],
				[700, 220],
				[180, 320],
				[340, 280],
				[510, 340],
				[660, 390],
				[90, 480],
				[250, 520],
				[400, 470],
				[560, 540],
				[720, 500],
				[160, 680],
				[330, 720],
				[490, 670],
				[640, 740]
			].map(([x, y], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: x,
				cy: y,
				r: i % 3 === 0 ? 5 : 3.5,
				className: i % 2 === 0 ? "fill-neon" : "fill-volt",
				opacity: .85
			}, `${x}-${y}`)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				className: "stroke-neon",
				strokeWidth: "1",
				fill: "none",
				opacity: "0.45",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M120 160 L260 110 L420 180 L580 130 L700 220" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M180 320 L340 280 L510 340 L660 390" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M90 480 L250 520 L400 470 L560 540 L720 500" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M160 680 L330 720 L490 670 L640 740" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M260 110 L340 280 L250 520 L330 720" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M420 180 L510 340 L400 470 L490 670" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M580 130 L660 390 L560 540 L640 740" })
				]
			})
		]
	});
}
//#endregion
export { Login as component };
