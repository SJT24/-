import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { t as authClient } from "./client-1vAx-gM_.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { r as cn } from "./utils-DAIVonyv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-current-user-BLNQxUcj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NeuralMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-8", className),
		"aria-hidden": true,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "32",
				height: "32",
				rx: "8",
				className: "fill-bg"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "0.6",
				y: "0.6",
				width: "30.8",
				height: "30.8",
				rx: "7.4",
				className: "stroke-neon",
				strokeWidth: "1.2",
				fill: "none"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "10",
				cy: "11",
				r: "2.1",
				className: "fill-neon"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "22",
				cy: "10",
				r: "1.7",
				className: "fill-volt"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "16",
				cy: "17",
				r: "2.4",
				className: "fill-neon"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "9",
				cy: "22",
				r: "1.6",
				className: "fill-volt"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "23",
				cy: "22",
				r: "1.9",
				className: "fill-neon"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M10 11 L16 17 L22 10 M16 17 L9 22 M16 17 L23 22",
				className: "stroke-neon",
				strokeWidth: "1.15",
				fill: "none",
				strokeLinecap: "round",
				opacity: "0.85"
			})
		]
	});
}
function UserMark({ name, hue, size = "md" }) {
	const ch = (name.trim().charAt(0) || "节").toUpperCase();
	const dim = size === "sm" ? "size-8 text-xs" : size === "lg" ? "size-20 text-2xl" : "size-10 text-sm";
	const inner = size === "sm" ? "rounded-sm" : size === "lg" ? "rounded-lg" : "rounded-md";
	const volt = hue % 2 === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("grid shrink-0 place-items-center rounded-lg bg-signal p-px", dim),
		"aria-hidden": true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: cn("grid size-full place-items-center bg-bg font-mono font-semibold", inner, volt ? "text-volt" : "text-neon"),
			children: ch
		})
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 font-medium transition-[opacity,transform,background-color,color,border-color,box-shadow] duration-150 ease-out active:not-disabled:scale-[0.98] disabled:pointer-events-none disabled:opacity-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon/40", {
	variants: {
		variant: {
			primary: "bg-signal text-neon-fg hover:shadow-neon font-semibold",
			outline: "border border-line bg-bg text-neon hover:border-neon hover:bg-surface-2",
			ghost: "text-muted hover:bg-surface-2 hover:text-fg",
			volt: "bg-volt text-neon-fg hover:opacity-90 font-semibold",
			danger: "bg-danger text-fg hover:opacity-90"
		},
		size: {
			sm: "h-9 rounded-md px-3 text-sm",
			md: "h-11 rounded-md px-4 text-sm",
			lg: "h-12 rounded-lg px-5 text-sm",
			icon: "size-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	}
});
var Button = (0, import_react.forwardRef)(function Button({ className, variant, size, ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		ref,
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...props
	});
});
var Input = (0, import_react.forwardRef)(function Input({ className, ...props }, ref) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		ref,
		className: cn("h-11 w-full rounded-md border border-line bg-bg px-3.5 text-sm text-fg placeholder:text-faint", "font-mono transition-[border-color,box-shadow] duration-150", "focus-visible:border-neon focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon/30", className),
		...props
	});
});
/**
* Current user + loading state. Same behavior in live preview and when deployed:
*   - Auth enabled -> the real signed-in user; `user` is `null` while
*                            the session resolves (`isPending: true`) and when
*                            signed out (`isPending: false`). Session comes from
*                            Better Auth `useSession()` → `/api/auth/get-session`
*                            (cookie when deployed; bearer in live preview).
*   - Auth disabled (`VITE_AUTH_ENABLED=false`) -> `DEV_USER`, never pending.
*
* Protect a route by waiting out `isPending` before acting on `user` —
* redirecting on `user: null` alone bounces signed-in visitors to sign-in on
* every hard reload:
*
*   import { RedirectToSignIn } from "@/lib/auth/gates";
*   const { user, isPending } = useCurrentUserState();
*   if (isPending) return null;              // still resolving — don't redirect yet
*   if (!user) return <RedirectToSignIn />;  // definitely signed out
*
* `authEnabled` is a module-level constant fixed at load, so the guarded hook
* call keeps a stable hook order across every render of a given component.
*/
function useCurrentUserState() {
	const { data, isPending } = authClient.useSession();
	const user = data?.user;
	return {
		user: user ? {
			id: user.id,
			displayName: user.name ?? null,
			primaryEmail: user.email ?? null,
			profileImageUrl: user.image ?? null,
			isDevFallback: false
		} : null,
		isPending
	};
}
/**
* Convenience view of `useCurrentUserState().user` for display (e.g.
* `user?.displayName ?? "Guest"`). NOTE: `null` means *loading OR signed out* —
* for redirects/guards use `useCurrentUserState()` and check `isPending`.
*/
function useCurrentUser() {
	return useCurrentUserState().user;
}
//#endregion
export { useCurrentUser as a, UserMark as i, Input as n, useCurrentUserState as o, NeuralMark as r, Button as t };
