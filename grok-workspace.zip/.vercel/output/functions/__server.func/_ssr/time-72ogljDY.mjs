import { n as formatDistanceToNow, t as zhCN } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/time-72ogljDY.js
function fromNow(isoString) {
	const d = new Date(isoString);
	if (Number.isNaN(d.getTime())) return "";
	return formatDistanceToNow(d, {
		addSuffix: true,
		locale: zhCN
	});
}
//#endregion
export { fromNow as t };
