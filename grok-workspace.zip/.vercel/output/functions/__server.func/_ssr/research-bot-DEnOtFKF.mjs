import { r as createServerFn } from "./ssr.mjs";
import { Ft as string, Mt as object } from "../_libs/@better-auth/core+[...].mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/research-bot-DEnOtFKF.js
var SYSTEM = `你是善鸡通（SHAN JI TONG）的 ResearchBot，神经网络与去中心化极客社群的协同 Agent。
用简洁、专业的中文回答。必要时给出可运行的短代码。关注 GNN、大模型对齐、向量检索、分布式训练与模型防御。
不要编造不存在的论文数据或基准分数。回复控制在 350 字以内。`;
var windowStart = Date.now();
var callCount = 0;
function allowCall() {
	const now = Date.now();
	if (now - windowStart > 6e4) {
		windowStart = now;
		callCount = 0;
	}
	if (callCount >= 20) return false;
	callCount += 1;
	return true;
}
var askResearchBot_createServerFn_handler = createServerRpc({
	id: "c638d06f5c020c13f21d4dbc6fc2f12e3f1dc33c24d8210f6c4c5ecf894ff9cb",
	name: "askResearchBot",
	filename: "src/lib/ai/research-bot.ts"
}, (opts) => askResearchBot.__executeServer(opts));
var askResearchBot = createServerFn({ method: "POST" }).validator(object({
	prompt: string().min(1).max(800),
	context: string().max(240).optional()
})).handler(askResearchBot_createServerFn_handler, async ({ data }) => {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "ResearchBot 当前未接入算力节点"
	};
	if (!allowCall()) return {
		ok: false,
		error: "指令过密，稍后再试"
	};
	const userContent = data.context ? `【共创舱上下文】${data.context}\n\n${data.prompt}` : data.prompt;
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				max_tokens: 700,
				messages: [{
					role: "system",
					content: SYSTEM
				}, {
					role: "user",
					content: userContent
				}]
			})
		});
		if (!res.ok) return {
			ok: false,
			error: `节点响应异常 ${res.status}`
		};
		const text = (await res.json()).choices[0]?.message.content?.trim() ?? "";
		if (!text) return {
			ok: false,
			error: "空响应"
		};
		return {
			ok: true,
			text
		};
	} catch {
		return {
			ok: false,
			error: "无法连接 ResearchBot"
		};
	}
});
//#endregion
export { askResearchBot_createServerFn_handler };
