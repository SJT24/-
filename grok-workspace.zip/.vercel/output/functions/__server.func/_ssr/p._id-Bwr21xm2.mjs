import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, o as require_react, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { C as useNavigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as UserMark, o as useCurrentUserState, t as Button } from "./use-current-user-BLNQxUcj.mjs";
import { a as Textarea, f as listComments, o as addComment, t as AppShell, u as getPost } from "./shell-BRQglFHi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { r as Route$2 } from "./router-CtMX8Eau.mjs";
import { t as fromNow } from "./time-72ogljDY.mjs";
import { t as PostCard } from "./post-card-DjEM3Xxo.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/p._id-Bwr21xm2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function PostPage() {
	const { id } = Route$2.useParams();
	const postId = Number(id);
	const navigate = useNavigate();
	const { user, isPending } = useCurrentUserState();
	const qc = useQueryClient();
	const [body, setBody] = (0, import_react.useState)("");
	const post = useQuery({
		queryKey: ["post", postId],
		queryFn: () => getPost({ data: { id: postId } }),
		enabled: Number.isFinite(postId)
	});
	const comments = useQuery({
		queryKey: ["comments", postId],
		queryFn: () => listComments({ data: { postId } }),
		enabled: Number.isFinite(postId)
	});
	const mut = useMutation({
		mutationFn: () => addComment({ data: {
			postId,
			body: body.trim()
		} }),
		onSuccess: () => {
			setBody("");
			qc.invalidateQueries({ queryKey: ["comments", postId] });
			qc.invalidateQueries({ queryKey: ["post", postId] });
			qc.invalidateQueries({ queryKey: ["feed"] });
		},
		onError: (err) => {
			if (err instanceof Error && err.message === "Unauthorized") {
				navigate({ to: "/login" });
				return;
			}
			toast.error("没能送出回应");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "text-sm text-muted underline-offset-4 hover:text-neon hover:underline",
				children: "返回神经网络"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4",
				children: [
					post.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-72 animate-pulse rounded-xl bg-surface-2" }) : null,
					post.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, { post: post.data }) : null,
					post.isSuccess && !post.data ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "py-16 text-center text-xl font-semibold",
						children: "这个节点已回收"
					}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-lg font-semibold",
						children: "讨论"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 space-y-4",
						children: [comments.data?.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/u/$handle",
								params: { handle: c.author.handle },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserMark, {
									name: c.author.displayName,
									hue: c.author.hue,
									size: "sm"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1 rounded-lg border border-line bg-bg px-3.5 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
										to: "/u/$handle",
										params: { handle: c.author.handle },
										className: "text-sm font-medium text-volt",
										children: c.author.displayName
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs text-faint",
										children: fromNow(c.createdAt)
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm leading-relaxed text-fg",
									children: c.body
								})]
							})]
						}, c.id)), comments.data?.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "还没有讨论。做第一个注入突触的人。"
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
						className: "mt-6 space-y-3",
						onSubmit: (e) => {
							e.preventDefault();
							if (!body.trim()) return;
							if (!isPending && !user) {
								navigate({ to: "/login" });
								return;
							}
							mut.mutate();
						},
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: body,
							onChange: (e) => setBody(e.target.value.slice(0, 280)),
							placeholder: "回复该神经网络节点…",
							className: "min-h-24"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "submit",
							disabled: mut.isPending || !body.trim(),
							children: "注入讨论"
						})]
					})
				]
			})
		]
	}) });
}
//#endregion
export { PostPage as component };
