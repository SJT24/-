import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, i as useQueryClient, n as useQuery, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as UserMark, o as useCurrentUserState } from "./use-current-user-BLNQxUcj.mjs";
import { _ as markRead, m as listNotifications, n as RedirectToSignIn, t as AppShell } from "./shell-BRQglFHi.mjs";
import { t as fromNow } from "./time-72ogljDY.mjs";
import { t as Skeleton } from "./skeleton-HMuGRFH-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/notifications-DgK4Vdcr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Notifications() {
	const { user, isPending } = useCurrentUserState();
	const qc = useQueryClient();
	const list = useQuery({
		queryKey: ["notifications"],
		queryFn: () => listNotifications(),
		enabled: Boolean(user)
	});
	(0, import_react.useEffect)(() => {
		if (!user) return;
		markRead().then(() => qc.invalidateQueries({ queryKey: ["unread"] })).catch(() => void 0);
	}, [user, qc]);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl space-y-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16 w-full" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-16 w-full" })]
	}) });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-widest text-faint",
				children: "SYNAPSE"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-2xl font-semibold",
				children: "突触通知"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 divide-y divide-line rounded-xl border border-line bg-surface",
				children: [list.data?.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "px-5 py-12 text-center text-sm text-muted",
					children: "还很安静。节点被点亮时，会来这里。"
				}) : null, list.data?.map((n) => {
					const text = n.type === "like" ? "为你的节点加权" : n.type === "comment" ? "回应了你的节点" : "接入了你的图谱";
					const inner = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 px-4 py-3.5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserMark, {
								name: n.actor.displayName,
								hue: n.actor.hue,
								size: "sm"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "min-w-0 flex-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-fg",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "font-medium",
											children: n.actor.displayName
										}),
										" ",
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
											className: "text-muted",
											children: text
										})
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-xs text-faint",
									children: fromNow(n.createdAt)
								})]
							}),
							!n.read ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2 shrink-0 rounded-full bg-volt" }) : null
						]
					});
					if (n.postId) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/p/$id",
						params: { id: String(n.postId) },
						children: inner
					}, n.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/u/$handle",
						params: { handle: n.actor.handle },
						children: inner
					}, n.id);
				})]
			})
		]
	}) });
}
//#endregion
export { Notifications as component };
