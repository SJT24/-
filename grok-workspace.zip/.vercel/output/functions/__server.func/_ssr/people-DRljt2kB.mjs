import { a as require_jsx_runtime, i as useQueryClient, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { C as useNavigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useCurrentUser, i as UserMark, t as Button } from "./use-current-user-BLNQxUcj.mjs";
import { v as toggleFollow } from "./shell-BRQglFHi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/people-DRljt2kB.js
var import_jsx_runtime = require_jsx_runtime();
function PersonRow({ person, compact = false }) {
	const user = useCurrentUser();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const isMe = user?.id === person.userId;
	const mut = useMutation({
		mutationFn: () => toggleFollow({ data: { userId: person.userId } }),
		onSuccess: () => {
			qc.invalidateQueries();
		},
		onError: (err) => {
			if (err instanceof Error && err.message === "Unauthorized") {
				navigate({ to: "/login" });
				return;
			}
			toast.error("未能更新连接");
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex items-start gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/u/$handle",
				params: { handle: person.handle },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserMark, {
					name: person.displayName,
					hue: person.hue,
					size: compact ? "sm" : "md"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/u/$handle",
						params: { handle: person.handle },
						className: "block truncate font-medium text-fg hover:text-neon",
						children: person.displayName
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate font-mono text-xs text-faint",
						children: [
							"@",
							person.handle,
							person.location ? ` · ${person.location}` : ""
						]
					}),
					!compact && person.bio ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 line-clamp-2 text-sm text-muted",
						children: person.bio
					}) : null
				]
			}),
			isMe ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: person.following ? "outline" : "primary",
				size: "sm",
				onClick: () => mut.mutate(),
				children: person.following ? "已连接" : "接入"
			})
		]
	});
}
//#endregion
export { PersonRow as t };
