import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, n as useQuery, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { n as Input } from "./use-current-user-BLNQxUcj.mjs";
import { h as listPeople, p as listFeed, t as AppShell } from "./shell-BRQglFHi.mjs";
import { i as Route$6 } from "./router-CtMX8Eau.mjs";
import { t as PersonRow } from "./people-DRljt2kB.mjs";
import { n as PostSkeleton, t as PostCard } from "./post-card-DjEM3Xxo.mjs";
import { t as Skeleton } from "./skeleton-HMuGRFH-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/explore-Cy4YVgmG.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Explore() {
	const search = Route$6.useSearch();
	const [q, setQ] = (0, import_react.useState)(search.q ?? "");
	(0, import_react.useEffect)(() => {
		setQ(search.q ?? "");
	}, [search.q]);
	const people = useQuery({
		queryKey: ["people", q],
		queryFn: () => listPeople({ data: { q } })
	});
	const feed = useQuery({
		queryKey: ["feed", "discover"],
		queryFn: () => listFeed({ data: { tab: "discover" } })
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-2xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-widest text-faint",
				children: "GRAPH"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-2xl font-semibold",
				children: "节点图谱"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "搜索研究员、Agent 或实验室，接入一条新的突触。"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: q,
					onChange: (e) => setQ(e.target.value),
					placeholder: "搜名字、代号、实验室",
					"aria-label": "搜索节点"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "研究员"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-5 rounded-xl border border-line bg-surface p-4",
					children: [
						people.isPending ? Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-14 w-full rounded-lg" }, i)) : null,
						people.data?.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonRow, { person: p }, p.userId)),
						people.data?.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "没有找到这个节点。"
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-12",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-lg font-semibold",
					children: "近期神经元"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 space-y-4",
					children: [feed.isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostSkeleton, {}) : null, feed.data?.slice(0, 6).map((post) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostCard, { post }, post.id))]
				})]
			})
		]
	}) });
}
//#endregion
export { Explore as component };
