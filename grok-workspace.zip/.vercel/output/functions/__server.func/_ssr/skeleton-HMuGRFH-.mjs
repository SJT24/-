import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { r as cn } from "./utils-DAIVonyv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/skeleton-HMuGRFH-.js
var import_jsx_runtime = require_jsx_runtime();
function Skeleton({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("animate-pulse rounded-md bg-surface-2", className),
		"aria-hidden": true
	});
}
//#endregion
export { Skeleton as t };
