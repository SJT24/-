import { o as __toESM } from "../_runtime.mjs";
import { a as require_jsx_runtime, o as require_react } from "../_libs/react+tanstack__react-query.mjs";
import { r as cn } from "./utils-DAIVonyv.mjs";
import { n as Input, t as Button } from "./use-current-user-BLNQxUcj.mjs";
import { o as Terminal, u as Plus, x as ArrowRight } from "../_libs/lucide-react.mjs";
import { a as Textarea, s as askResearchBot, t as AppShell, x as usePodStore } from "./shell-BRQglFHi.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pods-CnesoNmB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function nowStamp() {
	return (/* @__PURE__ */ new Date()).toLocaleTimeString("zh-CN", { hour12: false });
}
function PodsPage() {
	const pods = usePodStore((s) => s.pods);
	const addPod = usePodStore((s) => s.addPod);
	const [creating, setCreating] = (0, import_react.useState)(false);
	const [title, setTitle] = (0, import_react.useState)("");
	const [summary, setSummary] = (0, import_react.useState)("");
	const [active, setActive] = (0, import_react.useState)(pods[0] ?? null);
	const [cmd, setCmd] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [logs, setLogs] = (0, import_react.useState)([
		{
			t: nowStamp(),
			who: "ResearchBot",
			text: "初始化图神经网络拓扑流完成…",
			tone: "neon"
		},
		{
			t: nowStamp(),
			who: "System",
			text: "共创舱载入向量数据库权重参数…",
			tone: "muted"
		},
		{
			t: nowStamp(),
			who: "CodeAgent",
			text: "自动生成 GNN 前向传播单元测试通过。",
			tone: "volt"
		},
		{
			t: nowStamp(),
			who: "提示",
			text: "输入 /help 查看命令，/train 启动训练，/optimize 优化索引，或直接向 ResearchBot 提问。",
			tone: "faint"
		}
	]);
	function push(line) {
		setLogs((prev) => [...prev, {
			...line,
			t: nowStamp()
		}].slice(-80));
	}
	function onCreate(e) {
		e.preventDefault();
		if (!title.trim()) return;
		const pod = addPod({
			title: title.trim().slice(0, 40),
			summary: summary.trim().slice(0, 160) || "新建共创舱，等待 Agent 接入。"
		});
		setTitle("");
		setSummary("");
		setCreating(false);
		setActive(pod);
		push({
			who: "System",
			text: `共创舱 ${pod.id}「${pod.title}」已点燃。`,
			tone: "neon"
		});
	}
	async function runCommand(raw) {
		const text = raw.trim();
		if (!text || busy) return;
		setCmd("");
		push({
			who: "you",
			text,
			tone: "muted"
		});
		const ctx = active ? `${active.id} ${active.title}` : "未选择共创舱";
		if (text === "/help") {
			push({
				who: "System",
				text: "/train 启动分布式训练 · /optimize 优化向量索引 · /status 查看舱状态 · 其他输入将交给 ResearchBot",
				tone: "volt"
			});
			return;
		}
		if (text === "/status") {
			push({
				who: "System",
				text: active ? `${active.id} ${active.statusLabel} · 进度 ${active.progress}% · ${active.researchers} 人 + ${active.agents} AI` : "尚未进入共创舱",
				tone: "neon"
			});
			return;
		}
		if (text === "/train") {
			push({
				who: "CodeAgent",
				text: `已在 ${ctx} 排队分布式训练。预计 12 个 step 后回报 loss。`,
				tone: "volt"
			});
			return;
		}
		if (text === "/optimize") {
			push({
				who: "ResearchBot",
				text: `正在压缩 ${ctx} 的 HNSW 层。建议 ef=64，M=16。`,
				tone: "neon"
			});
			return;
		}
		setBusy(true);
		try {
			const res = await askResearchBot({ data: {
				prompt: text,
				context: ctx
			} });
			if (res.ok) push({
				who: "ResearchBot",
				text: res.text,
				tone: "neon"
			});
			else push({
				who: "System",
				text: res.error,
				tone: "muted"
			});
		} catch {
			push({
				who: "System",
				text: "无法连接 ResearchBot",
				tone: "muted"
			});
		} finally {
			setBusy(false);
		}
	}
	function onKey(e) {
		if (e.key === "Enter") {
			e.preventDefault();
			runCommand(cmd);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "size-2.5 rounded-full bg-volt" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "text-base font-bold tracking-wide",
						children: "AI 智能共创舱"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					onClick: () => setCreating((v) => !v),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {
						className: "size-3.5",
						strokeWidth: 2
					}), creating ? "收起" : "创建共创舱"]
				})]
			}),
			creating ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: onCreate,
				className: "space-y-3 rounded-xl border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: title,
						onChange: (e) => setTitle(e.target.value),
						placeholder: "共创舱名称，例如 稀疏图上的对比学习",
						maxLength: 40
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: summary,
						onChange: (e) => setSummary(e.target.value),
						placeholder: "一句话说明目标、要接入的 Agent 或数据集",
						className: "min-h-20",
						maxLength: 160
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: !title.trim(),
						children: "点燃共创舱"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-1 gap-4 md:grid-cols-2",
				children: pods.map((pod) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: cn("flex flex-col justify-between rounded-xl border bg-surface p-5 transition-colors duration-150", active?.id === pod.id ? "border-neon" : "border-line hover:border-line-strong"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mb-3 flex items-center justify-between gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: cn("rounded border border-line px-2 py-0.5 font-mono text-xs", pod.status === "live" ? "bg-neon/10 text-neon" : pod.status === "render" ? "bg-volt/10 text-volt" : "text-muted"),
								children: pod.statusLabel
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-mono text-xs text-volt",
								children: pod.id
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mb-2 text-base font-bold text-fg",
							children: pod.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mb-4 text-sm leading-relaxed text-muted",
							children: pod.summary
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-3 flex items-center justify-between border-t border-line pt-3 font-mono text-xs text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							"研究员 ",
							pod.researchers,
							" + AI ",
							pod.agents
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: pod.status === "render" ? "text-volt" : "text-neon",
							children: [
								"进度 ",
								pod.progress,
								"%"
							]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						className: "w-full",
						onClick: () => {
							setActive(pod);
							push({
								who: "System",
								text: `已进入 ${pod.id}「${pod.title}」。`,
								tone: "neon"
							});
						},
						children: ["进入共创舱调试", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-3.5" })]
					})] })]
				}, pod.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl border border-line bg-surface p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-4 flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Terminal, {
								className: "size-4 text-neon",
								strokeWidth: 1.8
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-sm font-bold",
								children: ["实时调试控制台", active ? ` · ${active.id}` : ""]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-mono text-xs text-faint",
							children: "wss://shanjitong.ai/agent/stream"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "h-52 space-y-2 overflow-y-auto rounded-lg border border-line bg-bg p-4 font-mono text-xs",
						children: [logs.map((line, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: cn(line.tone === "neon" && "text-neon", line.tone === "volt" && "text-volt", line.tone === "muted" && "text-muted", line.tone === "faint" && "italic text-faint"),
							children: [
								"[",
								line.t,
								"] ",
								line.who,
								": ",
								line.text
							]
						}, `${line.t}-${i}`)), busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "text-faint",
							children: "ResearchBot 推理中…"
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: cmd,
							onChange: (e) => setCmd(e.target.value),
							onKeyDown: onKey,
							placeholder: "输入命令（/train, /optimize, /status）或向 Agent 提问…",
							className: "flex-1"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							onClick: () => void runCommand(cmd),
							disabled: busy || !cmd.trim(),
							children: "执行指令"
						})]
					})
				]
			})
		]
	}) });
}
//#endregion
export { PodsPage as component };
