import { r as createServerFn } from "./ssr.mjs";
import { Ft as string, Mt as object, jt as number, wt as _enum } from "../_libs/@better-auth/core+[...].mjs";
import { i as iso, n as asInt, t as asBool } from "./utils-DAIVonyv.mjs";
import { r as getSql } from "./db-C6dnLI5w.mjs";
import { n as optionalAuth, t as authMiddleware } from "./optional-auth-BhJiqXVy.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/fns-7jOKNiEQ.js
var KEYS = new Set([
	{
		key: "clouds",
		src: "/traces/clouds.jpg",
		label: "云海"
	},
	{
		key: "tea",
		src: "/traces/tea.jpg",
		label: "茶田"
	},
	{
		key: "alley",
		src: "/traces/alley.jpg",
		label: "雨巷"
	},
	{
		key: "bamboo",
		src: "/traces/bamboo.jpg",
		label: "竹径"
	},
	{
		key: "lake",
		src: "/traces/lake.jpg",
		label: "碧湖"
	},
	{
		key: "poplar",
		src: "/traces/poplar.jpg",
		label: "胡杨"
	},
	{
		key: "lantern",
		src: "/traces/lantern.jpg",
		label: "夜灯"
	},
	{
		key: "snow",
		src: "/traces/snow.jpg",
		label: "雪峰"
	},
	{
		key: "window",
		src: "/traces/window.jpg",
		label: "窗前"
	}
].map((i) => i.key));
function isImageKey(value) {
	return Boolean(value && KEYS.has(value));
}
function handleBase(name, userId) {
	const latin = name.toLowerCase().replace(/[^a-z0-9]+/g, "").slice(0, 14);
	if (latin.length >= 2) return latin;
	return `node${userId.replace(/[^a-zA-Z0-9]/g, "").slice(-6).toLowerCase() || "ke"}`;
}
async function uniqueHandle(sql, base) {
	const cleaned = base.replace(/[^a-z0-9]/g, "").slice(0, 18) || "node";
	for (let i = 0; i < 40; i += 1) {
		const candidate = i === 0 ? cleaned : `${cleaned}${i + 1}`.slice(0, 22);
		if ((await sql`
      select 1 as n from profiles where handle = ${candidate} limit 1
    `).length === 0) return candidate;
	}
	return `${cleaned}${Date.now().toString(36).slice(-4)}`;
}
function mapPost(row) {
	return {
		id: asInt(row.id),
		body: row.body,
		imageKey: isImageKey(row.image_key) ? row.image_key : null,
		place: row.place ?? "",
		createdAt: iso(row.created_at),
		author: {
			userId: row.author_id,
			handle: row.handle,
			displayName: row.display_name,
			hue: asInt(row.hue)
		},
		likeCount: asInt(row.like_count),
		commentCount: asInt(row.comment_count),
		liked: asBool(row.liked)
	};
}
async function ensureRow(sql, userId) {
	if ((await sql`
    select 1 as n from profiles where user_id = ${userId} limit 1
  `).length) return;
	const name = "节点";
	await sql`
    insert into profiles (user_id, handle, display_name, hue)
    values (${userId}, ${await uniqueHandle(sql, handleBase(name, userId))}, ${name}, ${Math.abs([...userId].reduce((a, ch) => a + ch.charCodeAt(0), 0)) % 360})
    on conflict (user_id) do nothing
  `;
}
var ensureProfile_createServerFn_handler = createServerRpc({
	id: "665de9c19cf22f399ae34632b84f04240c9439f52cd766a0c6eeca9ae0e75a79",
	name: "ensureProfile",
	filename: "src/lib/social/fns.ts"
}, (opts) => ensureProfile.__executeServer(opts));
var ensureProfile = createServerFn({ method: "POST" }).validator(object({ displayName: string().max(40).optional() })).middleware([authMiddleware]).handler(ensureProfile_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const existing = await sql`
      select handle from profiles where user_id = ${context.userId} limit 1
    `;
	if (existing[0]) return {
		handle: existing[0].handle,
		created: false
	};
	const name = (data.displayName?.trim() || "节点").slice(0, 24);
	const handle = await uniqueHandle(sql, handleBase(name, context.userId));
	const hue = Math.abs([...context.userId].reduce((a, ch) => a + ch.charCodeAt(0), 0)) % 360;
	await sql`
      insert into profiles (user_id, handle, display_name, hue)
      values (${context.userId}, ${handle}, ${name}, ${hue})
    `;
	return {
		handle,
		created: true
	};
});
var listFeed_createServerFn_handler = createServerRpc({
	id: "4f02c05cfec80f11671eedf5d3a29af13507f045aaa35af52f111c9a77ba4b39",
	name: "listFeed",
	filename: "src/lib/social/fns.ts"
}, (opts) => listFeed.__executeServer(opts));
var listFeed = createServerFn({ method: "GET" }).validator(object({ tab: _enum(["discover", "following"]) })).middleware([optionalAuth]).handler(listFeed_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const me = context.userId;
	const likedParam = me ?? "__none__";
	if (data.tab === "following") {
		if (!me) return [];
		return (await sql`
        select
          p.id,
          p.body,
          p.image_key,
          p.place,
          p.created_at,
          pr.user_id as author_id,
          pr.handle,
          pr.display_name,
          pr.hue,
          (select count(*)::int from likes l where l.post_id = p.id) as like_count,
          (select count(*)::int from comments c where c.post_id = p.id) as comment_count,
          exists(select 1 from likes lx where lx.post_id = p.id and lx.user_id = ${me}) as liked
        from posts p
        join profiles pr on pr.user_id = p.user_id
        where p.user_id = ${me}
           or p.user_id in (select followee_id from follows where follower_id = ${me})
        order by p.created_at desc
        limit 40
      `).map(mapPost);
	}
	return (await sql`
      select
        p.id,
        p.body,
        p.image_key,
        p.place,
        p.created_at,
        pr.user_id as author_id,
        pr.handle,
        pr.display_name,
        pr.hue,
        (select count(*)::int from likes l where l.post_id = p.id) as like_count,
        (select count(*)::int from comments c where c.post_id = p.id) as comment_count,
        exists(select 1 from likes lx where lx.post_id = p.id and lx.user_id = ${likedParam}) as liked
      from posts p
      join profiles pr on pr.user_id = p.user_id
      order by p.created_at desc
      limit 40
    `).map(mapPost);
});
var getPost_createServerFn_handler = createServerRpc({
	id: "1c49668ea41268fc8d5dc7da6cb787b8e4db65aa75fc20db0a12f6ca6ae04e8a",
	name: "getPost",
	filename: "src/lib/social/fns.ts"
}, (opts) => getPost.__executeServer(opts));
var getPost = createServerFn({ method: "GET" }).validator(object({ id: number() })).middleware([optionalAuth]).handler(getPost_createServerFn_handler, async ({ context, data }) => {
	const rows = await (await getSql())`
      select
        p.id,
        p.body,
        p.image_key,
        p.place,
        p.created_at,
        pr.user_id as author_id,
        pr.handle,
        pr.display_name,
        pr.hue,
        (select count(*)::int from likes l where l.post_id = p.id) as like_count,
        (select count(*)::int from comments c where c.post_id = p.id) as comment_count,
        exists(select 1 from likes lx where lx.post_id = p.id and lx.user_id = ${context.userId ?? "__none__"}) as liked
      from posts p
      join profiles pr on pr.user_id = p.user_id
      where p.id = ${data.id}
      limit 1
    `;
	return rows[0] ? mapPost(rows[0]) : null;
});
var listComments_createServerFn_handler = createServerRpc({
	id: "300b39690af2b776d1a7efa268737e3423c32a536e658243efd7d6c6672e4067",
	name: "listComments",
	filename: "src/lib/social/fns.ts"
}, (opts) => listComments.__executeServer(opts));
var listComments = createServerFn({ method: "GET" }).validator(object({ postId: number() })).handler(listComments_createServerFn_handler, async ({ data }) => {
	return (await (await getSql())`
      select
        c.id, c.body, c.created_at,
        pr.user_id, pr.handle, pr.display_name, pr.hue
      from comments c
      join profiles pr on pr.user_id = c.user_id
      where c.post_id = ${data.postId}
      order by c.created_at asc
      limit 80
    `).map((r) => ({
		id: asInt(r.id),
		body: r.body,
		createdAt: iso(r.created_at),
		author: {
			userId: r.user_id,
			handle: r.handle,
			displayName: r.display_name,
			hue: asInt(r.hue)
		}
	}));
});
var createPost_createServerFn_handler = createServerRpc({
	id: "2e046f629e0a951555b8a8dccad4b150f583186b75d4e32a38c63833b7027faf",
	name: "createPost",
	filename: "src/lib/social/fns.ts"
}, (opts) => createPost.__executeServer(opts));
var createPost = createServerFn({ method: "POST" }).validator(object({
	body: string().min(1).max(1200),
	imageKey: string().nullable(),
	place: string().max(40)
})).middleware([authMiddleware]).handler(createPost_createServerFn_handler, async ({ context, data }) => {
	const body = data.body.trim();
	if (!body) throw new Error("写一句再发射");
	const imageKey = isImageKey(data.imageKey) ? data.imageKey : null;
	const place = data.place.trim().slice(0, 40);
	const sql = await getSql();
	await ensureRow(sql, context.userId);
	const rows = await sql`
      insert into posts (user_id, body, image_key, place)
      values (${context.userId}, ${body}, ${imageKey}, ${place})
      returning id
    `;
	return { id: asInt(rows[0]?.id) };
});
var deletePost_createServerFn_handler = createServerRpc({
	id: "17e57f89d2339fb72fad1f4ef2f64e41ce18f4a2fb3f02ce367d0243ddf99b84",
	name: "deletePost",
	filename: "src/lib/social/fns.ts"
}, (opts) => deletePost.__executeServer(opts));
var deletePost = createServerFn({ method: "POST" }).validator(object({ id: number() })).middleware([authMiddleware]).handler(deletePost_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureRow(sql, context.userId);
	await sql`
      delete from posts where id = ${data.id} and user_id = ${context.userId}
    `;
	return { ok: true };
});
var toggleLike_createServerFn_handler = createServerRpc({
	id: "01110e494549161e240e643d8b313f1465fa67b7cb84dc2ab2724447ae26e0fe",
	name: "toggleLike",
	filename: "src/lib/social/fns.ts"
}, (opts) => toggleLike.__executeServer(opts));
var toggleLike = createServerFn({ method: "POST" }).validator(object({ postId: number() })).middleware([authMiddleware]).handler(toggleLike_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureRow(sql, context.userId);
	if ((await sql`
      select 1 as n from likes
      where post_id = ${data.postId} and user_id = ${context.userId}
      limit 1
    `).length) {
		await sql`
        delete from likes
        where post_id = ${data.postId} and user_id = ${context.userId}
      `;
		return { liked: false };
	}
	await sql`
      insert into likes (post_id, user_id)
      values (${data.postId}, ${context.userId})
      on conflict do nothing
    `;
	const owner = await sql`
      select user_id from posts where id = ${data.postId} limit 1
    `;
	if (owner[0] && owner[0].user_id !== context.userId) await sql`
        insert into notifications (user_id, actor_id, type, post_id)
        values (${owner[0].user_id}, ${context.userId}, 'like', ${data.postId})
      `;
	return { liked: true };
});
var addComment_createServerFn_handler = createServerRpc({
	id: "831f5dd016321dca2d89f4c23834aa44038cf1be17ee18162cb25e878098c8f1",
	name: "addComment",
	filename: "src/lib/social/fns.ts"
}, (opts) => addComment.__executeServer(opts));
var addComment = createServerFn({ method: "POST" }).validator(object({
	postId: number(),
	body: string().min(1).max(280)
})).middleware([authMiddleware]).handler(addComment_createServerFn_handler, async ({ context, data }) => {
	const body = data.body.trim();
	if (!body) throw new Error("写一句回应");
	const sql = await getSql();
	await ensureRow(sql, context.userId);
	const rows = await sql`
      insert into comments (post_id, user_id, body)
      values (${data.postId}, ${context.userId}, ${body})
      returning id
    `;
	const owner = await sql`
      select user_id from posts where id = ${data.postId} limit 1
    `;
	if (owner[0] && owner[0].user_id !== context.userId) await sql`
        insert into notifications (user_id, actor_id, type, post_id)
        values (${owner[0].user_id}, ${context.userId}, 'comment', ${data.postId})
      `;
	return { id: asInt(rows[0]?.id) };
});
var toggleFollow_createServerFn_handler = createServerRpc({
	id: "53ae5660dd088d9ef0507d5e5a2901fdea09dd4126abeb11caf021eb0ad4d848",
	name: "toggleFollow",
	filename: "src/lib/social/fns.ts"
}, (opts) => toggleFollow.__executeServer(opts));
var toggleFollow = createServerFn({ method: "POST" }).validator(object({ userId: string().min(1) })).middleware([authMiddleware]).handler(toggleFollow_createServerFn_handler, async ({ context, data }) => {
	if (data.userId === context.userId) return { following: false };
	const sql = await getSql();
	await ensureRow(sql, context.userId);
	if ((await sql`
      select 1 as n from follows
      where follower_id = ${context.userId} and followee_id = ${data.userId}
      limit 1
    `).length) {
		await sql`
        delete from follows
        where follower_id = ${context.userId} and followee_id = ${data.userId}
      `;
		return { following: false };
	}
	await sql`
      insert into follows (follower_id, followee_id)
      values (${context.userId}, ${data.userId})
      on conflict do nothing
    `;
	await sql`
      insert into notifications (user_id, actor_id, type)
      values (${data.userId}, ${context.userId}, 'follow')
    `;
	return { following: true };
});
var getProfile_createServerFn_handler = createServerRpc({
	id: "90770bdeff735883284f14b7f5f7bc81a48f6fe56d46e06f9b976c0f6ac57bb4",
	name: "getProfile",
	filename: "src/lib/social/fns.ts"
}, (opts) => getProfile.__executeServer(opts));
var getProfile = createServerFn({ method: "GET" }).validator(object({ handle: string().min(1).max(32) })).middleware([optionalAuth]).handler(getProfile_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const p = (await sql`
      select user_id, handle, display_name, bio, location, hue, created_at
      from profiles
      where handle = ${data.handle.toLowerCase()}
      limit 1
    `)[0];
	if (!p) return null;
	const me = context.userId;
	const counts = await sql`
      select
        (select count(*)::int from posts where user_id = ${p.user_id}) as posts,
        (select count(*)::int from follows where followee_id = ${p.user_id}) as followers,
        (select count(*)::int from follows where follower_id = ${p.user_id}) as following
    `;
	let following = false;
	if (me && me !== p.user_id) following = (await sql`
        select 1 as n from follows
        where follower_id = ${me} and followee_id = ${p.user_id}
        limit 1
      `).length > 0;
	return {
		userId: p.user_id,
		handle: p.handle,
		displayName: p.display_name,
		bio: p.bio,
		location: p.location,
		hue: asInt(p.hue),
		createdAt: iso(p.created_at),
		postCount: asInt(counts[0]?.posts),
		followerCount: asInt(counts[0]?.followers),
		followingCount: asInt(counts[0]?.following),
		isMe: me === p.user_id,
		following
	};
});
var listUserPosts_createServerFn_handler = createServerRpc({
	id: "71869761a89f4aa6eccb9bf35e147db792f5989a445953f1645318d00ffa4d87",
	name: "listUserPosts",
	filename: "src/lib/social/fns.ts"
}, (opts) => listUserPosts.__executeServer(opts));
var listUserPosts = createServerFn({ method: "GET" }).validator(object({ userId: string().min(1) })).middleware([optionalAuth]).handler(listUserPosts_createServerFn_handler, async ({ context, data }) => {
	return (await (await getSql())`
      select
        p.id,
        p.body,
        p.image_key,
        p.place,
        p.created_at,
        pr.user_id as author_id,
        pr.handle,
        pr.display_name,
        pr.hue,
        (select count(*)::int from likes l where l.post_id = p.id) as like_count,
        (select count(*)::int from comments c where c.post_id = p.id) as comment_count,
        exists(select 1 from likes lx where lx.post_id = p.id and lx.user_id = ${context.userId ?? "__none__"}) as liked
      from posts p
      join profiles pr on pr.user_id = p.user_id
      where p.user_id = ${data.userId}
      order by p.created_at desc
      limit 40
    `).map(mapPost);
});
var updateProfile_createServerFn_handler = createServerRpc({
	id: "15d11417faffd91cf4b812bf89a98d8046960f7c7c3608871d20400f7d207878",
	name: "updateProfile",
	filename: "src/lib/social/fns.ts"
}, (opts) => updateProfile.__executeServer(opts));
var updateProfile = createServerFn({ method: "POST" }).validator(object({
	displayName: string().min(1).max(24),
	bio: string().max(120),
	location: string().max(24)
})).middleware([authMiddleware]).handler(updateProfile_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureRow(sql, context.userId);
	await sql`
      update profiles
      set
        display_name = ${data.displayName.trim().slice(0, 24)},
        bio = ${data.bio.trim().slice(0, 120)},
        location = ${data.location.trim().slice(0, 24)}
      where user_id = ${context.userId}
    `;
	return { ok: true };
});
var listPeople_createServerFn_handler = createServerRpc({
	id: "78123baf1821fcdea736903ac1b59490f05fbb62ef942e27c6f21e5e8cbb1ad0",
	name: "listPeople",
	filename: "src/lib/social/fns.ts"
}, (opts) => listPeople.__executeServer(opts));
var listPeople = createServerFn({ method: "GET" }).validator(object({ q: string().max(40).optional() })).middleware([optionalAuth]).handler(listPeople_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const me = context.userId ?? "__none__";
	const q = data.q?.trim() ?? "";
	const like = q ? `%${q}%` : "%";
	return (await sql`
      select
        pr.user_id,
        pr.handle,
        pr.display_name,
        pr.bio,
        pr.location,
        pr.hue,
        (select count(*)::int from follows f where f.followee_id = pr.user_id) as follower_count,
        exists(
          select 1 from follows x
          where x.follower_id = ${me} and x.followee_id = pr.user_id
        ) as following
      from profiles pr
      where (
        ${q} = ''
        or pr.handle ilike ${like}
        or pr.display_name ilike ${like}
        or pr.location ilike ${like}
      )
      order by follower_count desc, pr.created_at asc
      limit 24
    `).map((r) => ({
		userId: r.user_id,
		handle: r.handle,
		displayName: r.display_name,
		bio: r.bio,
		location: r.location,
		hue: asInt(r.hue),
		followerCount: asInt(r.follower_count),
		following: asBool(r.following)
	}));
});
var listNotifications_createServerFn_handler = createServerRpc({
	id: "71cfd6dde135218fc7b68aa73e8adc7e1245c946498a778cb7605158a0898638",
	name: "listNotifications",
	filename: "src/lib/social/fns.ts"
}, (opts) => listNotifications.__executeServer(opts));
var listNotifications = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listNotifications_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await ensureRow(sql, context.userId);
	return (await sql`
      select
        n.id, n.type, n.read, n.created_at, n.post_id,
        pr.user_id, pr.handle, pr.display_name, pr.hue
      from notifications n
      join profiles pr on pr.user_id = n.actor_id
      where n.user_id = ${context.userId}
      order by n.created_at desc
      limit 40
    `).map((r) => {
		const type = r.type === "comment" || r.type === "follow" || r.type === "like" ? r.type : "like";
		return {
			id: asInt(r.id),
			type,
			read: asBool(r.read),
			createdAt: iso(r.created_at),
			postId: r.post_id == null ? null : asInt(r.post_id),
			actor: {
				userId: r.user_id,
				handle: r.handle,
				displayName: r.display_name,
				hue: asInt(r.hue)
			}
		};
	});
});
var unreadCount_createServerFn_handler = createServerRpc({
	id: "0bb479efde4620b78cfd92627f84d612743295ea11f5f91e792b3ce3184cedca",
	name: "unreadCount",
	filename: "src/lib/social/fns.ts"
}, (opts) => unreadCount.__executeServer(opts));
var unreadCount = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(unreadCount_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await ensureRow(sql, context.userId);
	const rows = await sql`
      select count(*)::int as n
      from notifications
      where user_id = ${context.userId} and read = false
    `;
	return asInt(rows[0]?.n);
});
var markRead_createServerFn_handler = createServerRpc({
	id: "893f6ebedd1ab518a97dd8de382c04eba04579dc6a70388bb672753e98d581d2",
	name: "markRead",
	filename: "src/lib/social/fns.ts"
}, (opts) => markRead.__executeServer(opts));
var markRead = createServerFn({ method: "POST" }).middleware([authMiddleware]).handler(markRead_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await ensureRow(sql, context.userId);
	await sql`
      update notifications set read = true
      where user_id = ${context.userId} and read = false
    `;
	return { ok: true };
});
var myProfile_createServerFn_handler = createServerRpc({
	id: "d6bd68a704f1992e29151d47b6aaf783020de09bf4528edbaa96faeda2ded1f4",
	name: "myProfile",
	filename: "src/lib/social/fns.ts"
}, (opts) => myProfile.__executeServer(opts));
var myProfile = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(myProfile_createServerFn_handler, async ({ context }) => {
	const sql = await getSql();
	await ensureRow(sql, context.userId);
	const rows = await sql`
      select handle, display_name from profiles
      where user_id = ${context.userId}
      limit 1
    `;
	return rows[0] ? {
		handle: rows[0].handle,
		displayName: rows[0].display_name
	} : null;
});
var clusterStats_createServerFn_handler = createServerRpc({
	id: "89e4de22b23dd7e1aa5226d211044fdce261b640efda8e3b82cf10797cf5ea78",
	name: "clusterStats",
	filename: "src/lib/social/fns.ts"
}, (opts) => clusterStats.__executeServer(opts));
var clusterStats = createServerFn({ method: "GET" }).handler(clusterStats_createServerFn_handler, async () => {
	const rows = await (await getSql())`
      select
        (select count(*)::int from profiles) as nodes,
        (select count(*)::int from posts) as sparks,
        (select count(*)::int from comments) as links
    `;
	return {
		nodes: asInt(rows[0]?.nodes),
		sparks: asInt(rows[0]?.sparks),
		links: asInt(rows[0]?.links)
	};
});
//#endregion
export { addComment_createServerFn_handler, clusterStats_createServerFn_handler, createPost_createServerFn_handler, deletePost_createServerFn_handler, ensureProfile_createServerFn_handler, getPost_createServerFn_handler, getProfile_createServerFn_handler, listComments_createServerFn_handler, listFeed_createServerFn_handler, listNotifications_createServerFn_handler, listPeople_createServerFn_handler, listUserPosts_createServerFn_handler, markRead_createServerFn_handler, myProfile_createServerFn_handler, toggleFollow_createServerFn_handler, toggleLike_createServerFn_handler, unreadCount_createServerFn_handler, updateProfile_createServerFn_handler };
