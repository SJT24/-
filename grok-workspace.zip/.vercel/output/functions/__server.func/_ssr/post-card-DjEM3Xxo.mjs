import { a as require_jsx_runtime, i as useQueryClient, t as useMutation } from "../_libs/react+tanstack__react-query.mjs";
import { C as useNavigate, x as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { r as cn } from "./utils-DAIVonyv.mjs";
import { a as useCurrentUser, i as UserMark } from "./use-current-user-BLNQxUcj.mjs";
import { a as Trash2, h as Heart, p as MessageCircle, s as Share2, y as Bookmark } from "../_libs/lucide-react.mjs";
import { l as deletePost, y as toggleLike } from "./shell-BRQglFHi.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { t as fromNow } from "./time-72ogljDY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/post-card-DjEM3Xxo.js
var import_jsx_runtime = require_jsx_runtime();
function splitFences(raw) {
	const parts = [];
	const re = /```(\w*)\n([\s\S]*?)```/g;
	let last = 0;
	let match;
	while (match = re.exec(raw)) {
		if (match.index > last) parts.push({
			type: "text",
			value: raw.slice(last, match.index)
		});
		parts.push({
			type: "code",
			lang: match[1] ?? "",
			value: match[2].replace(/\n$/, "")
		});
		last = match.index + match[0].length;
	}
	if (last < raw.length) parts.push({
		type: "text",
		value: raw.slice(last)
	});
	return parts.filter((p) => p.value.trim().length > 0);
}
function PostBody({ text }) {
	const parts = splitFences(text);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: parts.map((part, i) => part.type === "code" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("pre", {
			className: "overflow-x-auto rounded-lg border border-line bg-bg p-3 font-mono text-xs leading-relaxed text-neon",
			children: [part.lang ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mb-2 font-mono text-xs uppercase tracking-widest text-faint",
				children: part.lang
			}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("code", { children: part.value })]
		}, i) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "whitespace-pre-wrap text-sm leading-relaxed text-fg",
			children: part.value.trim()
		}, i))
	});
}
function PostCard({ post, compact = false }) {
	const user = useCurrentUser();
	const navigate = useNavigate();
	const qc = useQueryClient();
	const isMine = Boolean(user && user.id === post.author.userId);
	const highlighted = post.author.handle === "researchbot" || /GNN|Agent|对齐/.test(post.body);
	const likeMut = useMutation({
		mutationFn: () => toggleLike({ data: { postId: post.id } }),
		onSuccess: () => {
			qc.invalidateQueries();
		},
		onError: (err) => {
			if (err instanceof Error && err.message === "Unauthorized") {
				navigate({ to: "/login" });
				return;
			}
			toast.error("未能同步权重");
		}
	});
	const delMut = useMutation({
		mutationFn: () => deletePost({ data: { id: post.id } }),
		onSuccess: () => {
			toast.success("节点已回收");
			qc.invalidateQueries();
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "relative overflow-hidden rounded-xl border border-line bg-surface p-5 transition-colors duration-150 hover:border-line-strong",
		children: [highlighted && !compact ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "absolute top-0 right-0 rounded-bl-lg border-b border-l border-line bg-neon/10 px-3 py-1 font-mono text-xs text-neon",
			children: "AI 智能高亮"
		}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-start gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/u/$handle",
				params: { handle: post.author.handle },
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserMark, {
					name: post.author.displayName,
					hue: post.author.hue
				})
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "min-w-0 flex-1",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-baseline gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/u/$handle",
								params: { handle: post.author.handle },
								className: "truncate font-semibold text-fg hover:text-neon",
								children: post.author.displayName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "rounded border border-line bg-surface-2 px-1.5 py-0.5 font-mono text-xs text-volt",
								children: ["@", post.author.handle]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "ml-auto shrink-0 font-mono text-xs tabular-nums text-faint",
								children: fromNow(post.createdAt)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/p/$id",
						params: { id: String(post.id) },
						className: "mt-3 block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PostBody, { text: post.body })
					}),
					post.place ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 font-mono text-xs text-muted",
						children: post.place
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex items-center gap-1 border-t border-line/80 pt-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => likeMut.mutate(),
								className: cn("inline-flex h-10 items-center gap-1.5 rounded-md px-2.5 text-sm transition-colors duration-150", post.liked ? "text-neon" : "text-muted hover:bg-surface-2 hover:text-neon"),
								"aria-pressed": post.liked,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heart, {
									className: "size-4",
									strokeWidth: 1.75,
									fill: post.liked ? "currentColor" : "none"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono tabular-nums",
									children: post.likeCount
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/p/$id",
								params: { id: String(post.id) },
								className: "inline-flex h-10 items-center gap-1.5 rounded-md px-2.5 text-sm text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-volt",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MessageCircle, {
									className: "size-4",
									strokeWidth: 1.75
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "font-mono tabular-nums",
									children: post.commentCount
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toast.success("已同步至量子档案"),
								className: "inline-flex h-10 items-center gap-1.5 rounded-md px-2.5 text-sm text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-neon",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Share2, {
									className: "size-4",
									strokeWidth: 1.75
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toast.success("已加入收藏夹"),
								className: "inline-flex size-10 items-center justify-center rounded-md text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-volt",
								"aria-label": "收藏",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bookmark, {
									className: "size-4",
									strokeWidth: 1.75
								})
							}),
							isMine ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => delMut.mutate(),
								className: "ml-auto inline-flex size-10 items-center justify-center rounded-md text-faint transition-colors duration-150 hover:bg-surface-2 hover:text-danger",
								"aria-label": "删除",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {
									className: "size-4",
									strokeWidth: 1.75
								})
							}) : null
						]
					})
				]
			})]
		})]
	});
}
function PostSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "overflow-hidden rounded-xl border border-line bg-surface p-5",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "size-10 animate-pulse rounded-lg bg-surface-2" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex-1 space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-1/3 animate-pulse rounded bg-surface-2" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-full animate-pulse rounded bg-surface-2" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-4 w-2/3 animate-pulse rounded bg-surface-2" })
				]
			})]
		})
	});
}
//#endregion
export { PostSkeleton as n, PostCard as t };
