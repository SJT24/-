import { a as require_jsx_runtime } from "../_libs/react+tanstack__react-query.mjs";
import { o as useCurrentUserState } from "./use-current-user-BLNQxUcj.mjs";
import { n as RedirectToSignIn, t as AppShell } from "./shell-BRQglFHi.mjs";
import { t as Composer } from "./composer-CIxF1Zpv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/compose-4xCKPRO3.js
var import_jsx_runtime = require_jsx_runtime();
function Compose() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mx-auto h-64 max-w-xl animate-pulse rounded-xl bg-surface-2" }) });
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-xl",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-mono text-xs tracking-widest text-faint",
				children: "TRANSMIT"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-1 text-2xl font-semibold",
				children: "发射一段神经元"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "灵感、架构、代码片段，都可以成为图谱上的一个节点。"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Composer, {})
			})
		]
	}) });
}
//#endregion
export { Compose as component };
