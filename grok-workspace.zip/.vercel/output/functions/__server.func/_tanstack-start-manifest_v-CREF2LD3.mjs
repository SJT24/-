//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CREF2LD3.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/compose",
			"/explore",
			"/login",
			"/notifications",
			"/pods",
			"/p/$id",
			"/u/$handle",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-mEvSQ0Z2.js",
			"/assets/react-DB-4Zxce.js",
			"/assets/preload-helper-NZvvZbDf.js",
			"/assets/link-CGFzApqw.js",
			"/assets/lazyRouteComponent-CFpsay_k.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-mEvSQ0Z2.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-Cd5PFTFo.js",
			"/assets/shell-CiBZQ-td.js",
			"/assets/post-card-UG4TzEb3.js",
			"/assets/composer-AUB_eWLS.js",
			"/assets/use-current-user-BnDzDCMw.js",
			"/assets/people-BfvomyaU.js"
		]
	},
	"/compose": {
		filePath: "/workspace/src/routes/compose.tsx",
		children: void 0,
		preloads: [
			"/assets/compose-Dx6TYhlk.js",
			"/assets/shell-CiBZQ-td.js",
			"/assets/composer-AUB_eWLS.js",
			"/assets/use-current-user-BnDzDCMw.js"
		]
	},
	"/explore": {
		filePath: "/workspace/src/routes/explore.tsx",
		children: void 0,
		preloads: [
			"/assets/explore-B1B3trwP.js",
			"/assets/shell-CiBZQ-td.js",
			"/assets/post-card-UG4TzEb3.js",
			"/assets/use-current-user-BnDzDCMw.js",
			"/assets/people-BfvomyaU.js",
			"/assets/skeleton-DtUQfP-L.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-Ca2y-1VI.js",
			"/assets/client-bLCk0icn.js",
			"/assets/use-current-user-BnDzDCMw.js"
		]
	},
	"/notifications": {
		filePath: "/workspace/src/routes/notifications.tsx",
		children: void 0,
		preloads: [
			"/assets/notifications-Dq_FRk5A.js",
			"/assets/shell-CiBZQ-td.js",
			"/assets/use-current-user-BnDzDCMw.js",
			"/assets/time-BKrPrbEi.js",
			"/assets/skeleton-DtUQfP-L.js"
		]
	},
	"/pods": {
		filePath: "/workspace/src/routes/pods.tsx",
		children: void 0,
		preloads: [
			"/assets/pods-CrjHrR25.js",
			"/assets/shell-CiBZQ-td.js",
			"/assets/use-current-user-BnDzDCMw.js"
		]
	},
	"/p/$id": {
		filePath: "/workspace/src/routes/p.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/p._id-CpIC-vlP.js",
			"/assets/shell-CiBZQ-td.js",
			"/assets/post-card-UG4TzEb3.js",
			"/assets/useMutation-D6Y0W4Jr.js",
			"/assets/use-current-user-BnDzDCMw.js",
			"/assets/time-BKrPrbEi.js"
		]
	},
	"/u/$handle": {
		filePath: "/workspace/src/routes/u.$handle.tsx",
		children: void 0,
		preloads: [
			"/assets/u._handle-CtYoLrJu.js",
			"/assets/shell-CiBZQ-td.js",
			"/assets/post-card-UG4TzEb3.js",
			"/assets/useMutation-D6Y0W4Jr.js",
			"/assets/use-current-user-BnDzDCMw.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
