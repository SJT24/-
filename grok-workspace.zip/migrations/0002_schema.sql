create table if not exists profiles (
  user_id      text primary key,
  handle       text not null unique,
  display_name text not null,
  bio          text not null default '',
  location     text not null default '',
  hue          integer not null default 140,
  is_seed      boolean not null default false,
  created_at   timestamptz not null default now()
);

create index if not exists profiles_handle_idx on profiles (handle);

create table if not exists posts (
  id         serial primary key,
  user_id    text not null references profiles(user_id) on delete cascade,
  body       text not null,
  image_key  text,
  place      text not null default '',
  created_at timestamptz not null default now()
);

create index if not exists posts_created_at_idx on posts (created_at desc);
create index if not exists posts_user_id_idx on posts (user_id);

create table if not exists likes (
  post_id    integer not null references posts(id) on delete cascade,
  user_id    text not null references profiles(user_id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (post_id, user_id)
);

create table if not exists comments (
  id         serial primary key,
  post_id    integer not null references posts(id) on delete cascade,
  user_id    text not null references profiles(user_id) on delete cascade,
  body       text not null,
  created_at timestamptz not null default now()
);

create index if not exists comments_post_id_idx on comments (post_id, created_at);

create table if not exists follows (
  follower_id text not null references profiles(user_id) on delete cascade,
  followee_id text not null references profiles(user_id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (follower_id, followee_id),
  check (follower_id <> followee_id)
);

create index if not exists follows_followee_idx on follows (followee_id);

create table if not exists notifications (
  id         serial primary key,
  user_id    text not null references profiles(user_id) on delete cascade,
  actor_id   text not null references profiles(user_id) on delete cascade,
  type       text not null,
  post_id    integer references posts(id) on delete cascade,
  read       boolean not null default false,
  created_at timestamptz not null default now()
);

create index if not exists notifications_user_idx on notifications (user_id, created_at desc);
