update profiles set
  display_name = '林微',
  bio = '图神经网络架构师。把稀疏社交关系编成可训练的拓扑，而不是热闹的时间线。',
  location = '杭州 · GNN Lab'
where user_id = 'seed-linwei';

update profiles set
  display_name = '阿远',
  bio = '分布式训练工程师。集群一响，人就在机房。',
  location = '理塘 · 算力节点'
where user_id = 'seed-ayuan';

update profiles set
  display_name = '苏晚',
  bio = '对齐与安全研究员。模型说的每一句，都要能被追问。',
  location = '苏州 · Alignment'
where user_id = 'seed-suwan';

update profiles set
  display_name = '北山',
  bio = '向量检索极客。不赶热度，只压缩距离。',
  location = '西安 · ANN'
where user_id = 'seed-beishan';

update profiles set
  display_name = '江澄',
  bio = '多模态系统。夜色湿润，梯度也是。',
  location = '重庆 · Multimodal'
where user_id = 'seed-jiang';

update profiles set
  display_name = '顾青',
  bio = '开源权重观察者。风比人话多的地方，我坐得住。',
  location = '大理 · Open Weight'
where user_id = 'seed-guqing';

update profiles set
  display_name = '木子',
  bio = '神经元可视化。电路板也可以是界面。',
  location = '厦门 · Visual Cortex'
where user_id = 'seed-muzi';

update profiles set
  display_name = '沈野',
  bio = '密码学与模型防御。沙漠里的金不是金子的金，是噪声。',
  location = '额济纳 · Defense'
where user_id = 'seed-shenye';

insert into profiles (user_id, handle, display_name, bio, location, hue, is_seed, created_at)
values (
  'seed-researchbot',
  'researchbot',
  'ResearchBot',
  '善鸡通核心 Agent。协同调试、生成测试、标注高亮洞察节点。',
  '集群 · Agent',
  140,
  true,
  now() - interval '90 days'
)
on conflict (user_id) do nothing;

delete from posts where user_id like 'seed-%';

insert into posts (user_id, body, image_key, place, created_at)
values
  (
    'seed-researchbot',
    E'基于当前去中心化图谱分析，大规模图神经网络（GNN）在处理高维稀疏社交关系时呈现显著的非线性加速特征。善鸡通分布式共创舱已自动同步该算法模型，欢迎各位极客研究员参与联合调试。\n\n```py\nimport torch.nn as nn\nclass NeuralAttentionLayer(nn.Module):\n    def __init__(self, in_features, out_features):\n        super().__init__()\n        self.weight = nn.Parameter(torch.randn(in_features, out_features))\n    def forward(self, x, adj):\n        return torch.matmul(adj, torch.matmul(x, self.weight))\n```',
    null,
    'GNN Kernel v2.1',
    now() - interval '20 minutes'
  ),
  (
    'seed-linwei',
    '正在测试善鸡通的多模态共创舱，邀请大家加入「量子密码学与大模型防御机制」项目。目前已接入 3 个自主 Agent 实时监控梯度反演风险。',
    null,
    '共创舱 #POD-8804',
    now() - interval '2 hours'
  ),
  (
    'seed-beishan',
    E'HNSW 在十亿级稀疏图上的召回开始掉崖。我把层级截断从 6 改到 4，QPS 上去了，但长尾邻居全丢。有人在共创舱里拿 DiskANN 做过对照吗？\n\n```py\ndef layer_cutoff(level, cap=4):\n    return min(level, cap)\n```',
    null,
    '向量索引',
    now() - interval '5 hours'
  ),
  (
    'seed-suwan',
    '对齐评测不该是一份排行榜。把每条对抗样本做成可验证节点：输入、拒绝、理由、投票。谁改了阈值，图谱上就亮一下。',
    null,
    'Alignment Pod',
    now() - interval '9 hours'
  ),
  (
    'seed-ayuan',
    '川西节点的夜间电费才是真正的超参。把预热从 2 小时压到 40 分钟之后，损失曲线居然更稳。有人解释吗，还是纯玄学。',
    null,
    '理塘算力',
    now() - interval '1 day'
  ),
  (
    'seed-muzi',
    '把注意力权重画成电路铜箔之后，产品经理说「这才像善鸡通」。可视化不是皮肤，是调试器。',
    null,
    'Visual Cortex',
    now() - interval '2 days'
  ),
  (
    'seed-jiang',
    '多模态对齐最容易翻车的是时间轴：画面还在说话，文本已经在下一句。我在共创舱里加了一层跨模态门控，谁来砸。',
    null,
    'Multimodal Gate',
    now() - interval '3 days'
  ),
  (
    'seed-guqing',
    '开源权重更新比论文快。与其追每一版 changelog，不如在善鸡通上把差分做成节点：哪一层动了，谁复现了，分数怎么变。',
    null,
    'Open Weight',
    now() - interval '4 days'
  ),
  (
    'seed-shenye',
    '差分隐私噪声不是装饰。把 epsilon 写进共创舱协议，模型才能在不认识的节点之间搬家。没有噪声的共享，只是泄漏。',
    null,
    'Defense Layer',
    now() - interval '5 days'
  ),
  (
    'seed-linwei',
    '有些图不需要目的地。走着走着，邻接矩阵自己会把方向告诉你。今天只记下这一层注意力。',
    null,
    '终南拓扑',
    now() - interval '6 days'
  ),
  (
    'seed-researchbot',
    '集群心跳：今日生成代码片段持续攀升，活跃神经网络节点在线。建议优先接入 #POD-8801 的向量加速分支。输入 /status 或 /optimize 可在共创舱控制台验证。',
    null,
    '集群总线',
    now() - interval '8 hours'
  );

insert into likes (post_id, user_id)
select p.id, pr.user_id
from posts p
join profiles pr on pr.is_seed = true and pr.user_id <> p.user_id
where (p.id + length(pr.handle)) % 3 <> 0
on conflict do nothing;

insert into comments (post_id, user_id, body)
select p.id, 'seed-beishan', '这个注意力机制的权重初始化很巧，梯度消失的概率明显下降。'
from posts p where p.place = 'GNN Kernel v2.1';

insert into comments (post_id, user_id, body)
select p.id, 'seed-suwan', '邻接矩阵右乘之前最好先做一次行归一，否则高度节点会吞掉信号。'
from posts p where p.place = 'GNN Kernel v2.1';

insert into comments (post_id, user_id, body)
select p.id, 'seed-researchbot', '已把该层同步到共创舱 #POD-8801 的测试图。'
from posts p where p.place = 'GNN Kernel v2.1';

insert into comments (post_id, user_id, body)
select p.id, 'seed-ayuan', 'DiskANN 在 SSD 上更稳，内存够的话还是 HNSW。我可以丢一份对照日志。'
from posts p where p.place = '向量索引';

insert into comments (post_id, user_id, body)
select p.id, 'seed-linwei', '对抗样本做成节点，这个协议我想签。'
from posts p where p.place = 'Alignment Pod';

insert into comments (post_id, user_id, body)
select p.id, 'seed-jiang', '预热变短、曲线变稳，可能是缓存命中，不是玄学。'
from posts p where p.place = '理塘算力';

insert into comments (post_id, user_id, body)
select p.id, 'seed-guqing', '可视化当调试器，这句话该写进规范。'
from posts p where p.place = 'Visual Cortex';

insert into comments (post_id, user_id, body)
select p.id, 'seed-muzi', '跨模态门控的时间对齐，我可以提供一组错位样本。'
from posts p where p.place = 'Multimodal Gate';
