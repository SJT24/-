import { useEffect, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/shell";
import { PersonRow } from "@/components/people";
import { PostCard, PostSkeleton } from "@/components/post-card";
import { Input } from "@/components/ui/input";
import { listFeed, listPeople } from "@/lib/social/fns";
import { Skeleton } from "@/components/ui/skeleton";

type ExploreSearch = { q?: string };

export const Route = createFileRoute("/explore")({
  validateSearch: (s: Record<string, unknown>): ExploreSearch => ({
    q: typeof s.q === "string" ? s.q : "",
  }),
  component: Explore,
});

function Explore() {
  const search = Route.useSearch();
  const [q, setQ] = useState(search.q ?? "");
  useEffect(() => {
    setQ(search.q ?? "");
  }, [search.q]);
  const people = useQuery({
    queryKey: ["people", q],
    queryFn: () => listPeople({ data: { q } }),
  });
  const feed = useQuery({
    queryKey: ["feed", "discover"],
    queryFn: () => listFeed({ data: { tab: "discover" } }),
  });

  return (
    <AppShell>
      <div className="mx-auto max-w-2xl">
        <p className="font-mono text-xs tracking-widest text-faint">GRAPH</p>
        <h1 className="mt-1 text-2xl font-semibold">节点图谱</h1>
        <p className="mt-2 text-sm text-muted">
          搜索研究员、Agent 或实验室，接入一条新的突触。
        </p>

        <div className="mt-6">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="搜名字、代号、实验室"
            aria-label="搜索节点"
          />
        </div>

        <section className="mt-8">
          <h2 className="text-lg font-semibold">研究员</h2>
          <div className="mt-4 space-y-5 rounded-xl border border-line bg-surface p-4">
            {people.isPending
              ? Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-14 w-full rounded-lg" />
                ))
              : null}
            {people.data?.map((p) => (
              <PersonRow key={p.userId} person={p} />
            ))}
            {people.data?.length === 0 ? (
              <p className="text-sm text-muted">没有找到这个节点。</p>
            ) : null}
          </div>
        </section>

        <section className="mt-12">
          <h2 className="text-lg font-semibold">近期神经元</h2>
          <div className="mt-4 space-y-4">
            {feed.isPending ? <PostSkeleton /> : null}
            {feed.data?.slice(0, 6).map((post) => (
              <PostCard key={post.id} post={post} />
            ))}
          </div>
        </section>
      </div>
    </AppShell>
  );
}
