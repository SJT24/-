import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/shell";
import { Composer } from "@/components/composer";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/compose")({ component: Compose });

function Compose() {
  const { user, isPending } = useCurrentUserState();

  if (isPending) {
    return (
      <AppShell>
        <div className="mx-auto h-64 max-w-xl animate-pulse rounded-xl bg-surface-2" />
      </AppShell>
    );
  }
  if (!user) return <RedirectToSignIn />;

  return (
    <AppShell>
      <div className="mx-auto max-w-xl">
        <p className="font-mono text-xs tracking-widest text-faint">TRANSMIT</p>
        <h1 className="mt-1 text-2xl font-semibold">发射一段神经元</h1>
        <p className="mt-2 text-sm text-muted">
          灵感、架构、代码片段，都可以成为图谱上的一个节点。
        </p>
        <div className="mt-6">
          <Composer />
        </div>
      </div>
    </AppShell>
  );
}
