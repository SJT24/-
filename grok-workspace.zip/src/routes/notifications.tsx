import { useEffect } from "react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { AppShell } from "@/components/shell";
import { UserMark } from "@/components/mark";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { listNotifications, markRead } from "@/lib/social/fns";
import { fromNow } from "@/lib/social/time";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/notifications")({
  component: Notifications,
});

function Notifications() {
  const { user, isPending } = useCurrentUserState();
  const qc = useQueryClient();
  const list = useQuery({
    queryKey: ["notifications"],
    queryFn: () => listNotifications(),
    enabled: Boolean(user),
  });

  useEffect(() => {
    if (!user) return;
    markRead()
      .then(() => qc.invalidateQueries({ queryKey: ["unread"] }))
      .catch(() => undefined);
  }, [user, qc]);

  if (isPending) {
    return (
      <AppShell>
        <div className="mx-auto max-w-xl space-y-3">
          <Skeleton className="h-16 w-full" />
          <Skeleton className="h-16 w-full" />
        </div>
      </AppShell>
    );
  }
  if (!user) return <RedirectToSignIn />;

  return (
    <AppShell>
      <div className="mx-auto max-w-xl">
        <p className="font-mono text-xs tracking-widest text-faint">SYNAPSE</p>
        <h1 className="mt-1 text-2xl font-semibold">突触通知</h1>
        <div className="mt-6 divide-y divide-line rounded-xl border border-line bg-surface">
          {list.data?.length === 0 ? (
            <p className="px-5 py-12 text-center text-sm text-muted">
              还很安静。节点被点亮时，会来这里。
            </p>
          ) : null}
          {list.data?.map((n) => {
            const text =
              n.type === "like"
                ? "为你的节点加权"
                : n.type === "comment"
                  ? "回应了你的节点"
                  : "接入了你的图谱";
            const inner = (
              <div className="flex items-center gap-3 px-4 py-3.5">
                <UserMark name={n.actor.displayName} hue={n.actor.hue} size="sm" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm text-fg">
                    <span className="font-medium">{n.actor.displayName}</span>{" "}
                    <span className="text-muted">{text}</span>
                  </p>
                  <p className="font-mono text-xs text-faint">{fromNow(n.createdAt)}</p>
                </div>
                {!n.read ? (
                  <span className="size-2 shrink-0 rounded-full bg-volt" />
                ) : null}
              </div>
            );
            if (n.postId) {
              return (
                <Link key={n.id} to="/p/$id" params={{ id: String(n.postId) }}>
                  {inner}
                </Link>
              );
            }
            return (
              <Link
                key={n.id}
                to="/u/$handle"
                params={{ handle: n.actor.handle }}
              >
                {inner}
              </Link>
            );
          })}
        </div>
      </div>
    </AppShell>
  );
}
