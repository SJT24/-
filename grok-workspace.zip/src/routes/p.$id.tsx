import { useState } from "react";
import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { AppShell } from "@/components/shell";
import { PostCard } from "@/components/post-card";
import { UserMark } from "@/components/mark";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { addComment, getPost, listComments } from "@/lib/social/fns";
import { fromNow } from "@/lib/social/time";
import { useCurrentUser, useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/p/$id")({ component: PostPage });

function PostPage() {
  const { id } = Route.useParams();
  const postId = Number(id);
  const navigate = useNavigate();
  const { user, isPending } = useCurrentUserState();
  const qc = useQueryClient();
  const [body, setBody] = useState("");

  const post = useQuery({
    queryKey: ["post", postId],
    queryFn: () => getPost({ data: { id: postId } }),
    enabled: Number.isFinite(postId),
  });
  const comments = useQuery({
    queryKey: ["comments", postId],
    queryFn: () => listComments({ data: { postId } }),
    enabled: Number.isFinite(postId),
  });

  const mut = useMutation({
    mutationFn: () => addComment({ data: { postId, body: body.trim() } }),
    onSuccess: () => {
      setBody("");
      void qc.invalidateQueries({ queryKey: ["comments", postId] });
      void qc.invalidateQueries({ queryKey: ["post", postId] });
      void qc.invalidateQueries({ queryKey: ["feed"] });
    },
    onError: (err) => {
      if (err instanceof Error && err.message === "Unauthorized") {
        void navigate({ to: "/login" });
        return;
      }
      toast.error("没能送出回应");
    },
  });

  return (
    <AppShell>
      <div className="mx-auto max-w-2xl">
        <Link
          to="/"
          className="text-sm text-muted underline-offset-4 hover:text-neon hover:underline"
        >
          返回神经网络
        </Link>
        <div className="mt-4">
          {post.isPending ? (
            <div className="h-72 animate-pulse rounded-xl bg-surface-2" />
          ) : null}
          {post.data ? <PostCard post={post.data} /> : null}
          {post.isSuccess && !post.data ? (
            <p className="py-16 text-center text-xl font-semibold">这个节点已回收</p>
          ) : null}
        </div>

        <section className="mt-8">
          <h2 className="text-lg font-semibold">讨论</h2>
          <div className="mt-4 space-y-4">
            {comments.data?.map((c) => (
              <div key={c.id} className="flex gap-3">
                <Link to="/u/$handle" params={{ handle: c.author.handle }}>
                  <UserMark name={c.author.displayName} hue={c.author.hue} size="sm" />
                </Link>
                <div className="min-w-0 flex-1 rounded-lg border border-line bg-bg px-3.5 py-3">
                  <div className="flex items-baseline gap-2">
                    <Link
                      to="/u/$handle"
                      params={{ handle: c.author.handle }}
                      className="text-sm font-medium text-volt"
                    >
                      {c.author.displayName}
                    </Link>
                    <span className="font-mono text-xs text-faint">
                      {fromNow(c.createdAt)}
                    </span>
                  </div>
                  <p className="mt-1 text-sm leading-relaxed text-fg">{c.body}</p>
                </div>
              </div>
            ))}
            {comments.data?.length === 0 ? (
              <p className="text-sm text-muted">还没有讨论。做第一个注入突触的人。</p>
            ) : null}
          </div>

          <form
            className="mt-6 space-y-3"
            onSubmit={(e) => {
              e.preventDefault();
              if (!body.trim()) return;
              if (!isPending && !user) {
                void navigate({ to: "/login" });
                return;
              }
              mut.mutate();
            }}
          >
            <Textarea
              value={body}
              onChange={(e) => setBody(e.target.value.slice(0, 280))}
              placeholder="回复该神经网络节点…"
              className="min-h-24"
            />
            <Button type="submit" disabled={mut.isPending || !body.trim()}>
              注入讨论
            </Button>
          </form>
        </section>
      </div>
    </AppShell>
  );
}
