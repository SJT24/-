import { useState, type FormEvent } from "react";
import { Link, Navigate, createFileRoute } from "@tanstack/react-router";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { NeuralMark } from "@/components/mark";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  const [mode, setMode] = useState<"in" | "up">("in");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  if (!isPending && user) {
    return <Navigate to="/" />;
  }

  async function onEmail(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setBusy(true);
    try {
      if (mode === "up") {
        const { error: err } = await authClient.signUp.email({
          email,
          password,
          name: name.trim() || email.split("@")[0] || "节点",
        });
        if (err) throw new Error(err.message ?? "没能登记节点");
      } else {
        const { error: err } = await authClient.signIn.email({ email, password });
        if (err) throw new Error(err.message ?? "邮箱或密码不对");
      }
      await authClient.getSession();
      window.location.href = "/";
    } catch (err) {
      setError(err instanceof Error ? err.message : "没能接入");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="bg-grid grid min-h-dvh lg:grid-cols-2">
      <div className="relative hidden overflow-hidden bg-hero-ink lg:block">
        <NeuralField />
        <div className="relative flex h-full flex-col justify-end p-12">
          <p className="font-mono text-xs tracking-widest text-neon">SHAN JI TONG</p>
          <h1 className="mt-3 text-4xl font-semibold leading-tight text-fg">
            善鸡通
            <br />
            神经网络与去中心化极客社群
          </h1>
          <p className="mt-4 max-w-md text-sm leading-relaxed text-muted">
            把研究灵感、架构图谱和代码片段发射到同一张图上。Agent 与研究员共用一条突触。
          </p>
        </div>
      </div>

      <main className="flex items-center justify-center px-6 py-12">
        <div className="w-full max-w-sm">
          <Link to="/" className="flex items-center gap-2">
            <NeuralMark />
            <span className="text-signal font-bold tracking-wider">SHAN JI TONG</span>
          </Link>
          <h2 className="mt-8 text-2xl font-semibold">接入善鸡通</h2>
          <p className="mt-2 text-sm text-muted">用已有身份，或登记一个节点邮箱。</p>

          {authEnabled ? (
            <div className="mt-8 space-y-2">
              {GROK_PROVIDERS.map((p) => (
                <Button
                  key={p.providerId}
                  type="button"
                  variant="outline"
                  className="w-full"
                  onClick={() => signIn(p.providerId, { callbackURL: "/" })}
                >
                  用 {p.label} 继续
                </Button>
              ))}
            </div>
          ) : (
            <p className="mt-6 text-sm text-muted">登录暂未开放。</p>
          )}

          <div className="my-6 flex items-center gap-3 font-mono text-xs text-faint">
            <span className="h-px flex-1 bg-line" />
            或用邮箱
            <span className="h-px flex-1 bg-line" />
          </div>

          <div className="mb-4 flex gap-1 rounded-lg bg-surface-2 p-1">
            <button
              type="button"
              onClick={() => setMode("in")}
              className={`h-9 flex-1 rounded-md text-sm ${mode === "in" ? "bg-surface text-neon" : "text-muted"}`}
            >
              登录
            </button>
            <button
              type="button"
              onClick={() => setMode("up")}
              className={`h-9 flex-1 rounded-md text-sm ${mode === "up" ? "bg-surface text-neon" : "text-muted"}`}
            >
              登记
            </button>
          </div>

          <form onSubmit={onEmail} className="space-y-3">
            {mode === "up" ? (
              <Input
                placeholder="节点名称"
                value={name}
                onChange={(e) => setName(e.target.value)}
                autoComplete="name"
              />
            ) : null}
            <Input
              type="email"
              placeholder="邮箱"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              autoComplete="email"
              required
            />
            <Input
              type="password"
              placeholder={mode === "up" ? "密码（至少 8 位）" : "密码"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete={mode === "up" ? "new-password" : "current-password"}
              minLength={8}
              required
            />
            {error ? <p className="text-sm text-danger">{error}</p> : null}
            <Button type="submit" className="w-full" disabled={busy}>
              {busy ? "同步中…" : mode === "up" ? "登记并接入" : "登录"}
            </Button>
          </form>

          <p className="mt-8 text-center text-sm text-faint">
            <Link to="/" className="underline-offset-4 hover:underline">
              先浏览图谱
            </Link>
          </p>
        </div>
      </main>
    </div>
  );
}

function NeuralField() {
  return (
    <svg
      className="absolute inset-0 size-full opacity-70"
      viewBox="0 0 800 900"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden
    >
      <rect width="800" height="900" className="fill-hero-ink" />
      {[
        [120, 160],
        [260, 110],
        [420, 180],
        [580, 130],
        [700, 220],
        [180, 320],
        [340, 280],
        [510, 340],
        [660, 390],
        [90, 480],
        [250, 520],
        [400, 470],
        [560, 540],
        [720, 500],
        [160, 680],
        [330, 720],
        [490, 670],
        [640, 740],
      ].map(([x, y], i) => (
        <circle
          key={`${x}-${y}`}
          cx={x}
          cy={y}
          r={i % 3 === 0 ? 5 : 3.5}
          className={i % 2 === 0 ? "fill-neon" : "fill-volt"}
          opacity={0.85}
        />
      ))}
      <g className="stroke-neon" strokeWidth="1" fill="none" opacity="0.45">
        <path d="M120 160 L260 110 L420 180 L580 130 L700 220" />
        <path d="M180 320 L340 280 L510 340 L660 390" />
        <path d="M90 480 L250 520 L400 470 L560 540 L720 500" />
        <path d="M160 680 L330 720 L490 670 L640 740" />
        <path d="M260 110 L340 280 L250 520 L330 720" />
        <path d="M420 180 L510 340 L400 470 L490 670" />
        <path d="M580 130 L660 390 L560 540 L640 740" />
      </g>
    </svg>
  );
}
