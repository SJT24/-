import { useState, type FormEvent, type KeyboardEvent } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { ArrowRight, Plus, Terminal } from "lucide-react";
import { AppShell } from "@/components/shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { askResearchBot } from "@/lib/ai/research-bot";
import { usePodStore, type Pod } from "@/lib/social/pods";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/pods")({ component: PodsPage });

type LogLine = { t: string; who: string; text: string; tone: "neon" | "volt" | "muted" | "faint" };

function nowStamp() {
  return new Date().toLocaleTimeString("zh-CN", { hour12: false });
}

function PodsPage() {
  const pods = usePodStore((s) => s.pods);
  const addPod = usePodStore((s) => s.addPod);
  const [creating, setCreating] = useState(false);
  const [title, setTitle] = useState("");
  const [summary, setSummary] = useState("");
  const [active, setActive] = useState<Pod | null>(pods[0] ?? null);
  const [cmd, setCmd] = useState("");
  const [busy, setBusy] = useState(false);
  const [logs, setLogs] = useState<LogLine[]>([
    { t: nowStamp(), who: "ResearchBot", text: "初始化图神经网络拓扑流完成…", tone: "neon" },
    { t: nowStamp(), who: "System", text: "共创舱载入向量数据库权重参数…", tone: "muted" },
    { t: nowStamp(), who: "CodeAgent", text: "自动生成 GNN 前向传播单元测试通过。", tone: "volt" },
    {
      t: nowStamp(),
      who: "提示",
      text: "输入 /help 查看命令，/train 启动训练，/optimize 优化索引，或直接向 ResearchBot 提问。",
      tone: "faint",
    },
  ]);

  function push(line: Omit<LogLine, "t">) {
    setLogs((prev) => [...prev, { ...line, t: nowStamp() }].slice(-80));
  }

  function onCreate(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) return;
    const pod = addPod({
      title: title.trim().slice(0, 40),
      summary: summary.trim().slice(0, 160) || "新建共创舱，等待 Agent 接入。",
    });
    setTitle("");
    setSummary("");
    setCreating(false);
    setActive(pod);
    push({
      who: "System",
      text: `共创舱 ${pod.id}「${pod.title}」已点燃。`,
      tone: "neon",
    });
  }

  async function runCommand(raw: string) {
    const text = raw.trim();
    if (!text || busy) return;
    setCmd("");
    push({ who: "you", text, tone: "muted" });
    const ctx = active ? `${active.id} ${active.title}` : "未选择共创舱";

    if (text === "/help") {
      push({
        who: "System",
        text: "/train 启动分布式训练 · /optimize 优化向量索引 · /status 查看舱状态 · 其他输入将交给 ResearchBot",
        tone: "volt",
      });
      return;
    }
    if (text === "/status") {
      push({
        who: "System",
        text: active
          ? `${active.id} ${active.statusLabel} · 进度 ${active.progress}% · ${active.researchers} 人 + ${active.agents} AI`
          : "尚未进入共创舱",
        tone: "neon",
      });
      return;
    }
    if (text === "/train") {
      push({
        who: "CodeAgent",
        text: `已在 ${ctx} 排队分布式训练。预计 12 个 step 后回报 loss。`,
        tone: "volt",
      });
      return;
    }
    if (text === "/optimize") {
      push({
        who: "ResearchBot",
        text: `正在压缩 ${ctx} 的 HNSW 层。建议 ef=64，M=16。`,
        tone: "neon",
      });
      return;
    }

    setBusy(true);
    try {
      const res = await askResearchBot({
        data: { prompt: text, context: ctx },
      });
      if (res.ok) {
        push({ who: "ResearchBot", text: res.text, tone: "neon" });
      } else {
        push({ who: "System", text: res.error, tone: "muted" });
      }
    } catch {
      push({ who: "System", text: "无法连接 ResearchBot", tone: "muted" });
    } finally {
      setBusy(false);
    }
  }

  function onKey(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter") {
      e.preventDefault();
      void runCommand(cmd);
    }
  }

  return (
    <AppShell>
      <div className="space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface p-4">
          <div className="flex items-center gap-2">
            <span className="size-2.5 rounded-full bg-volt" />
            <h1 className="text-base font-bold tracking-wide">AI 智能共创舱</h1>
          </div>
          <Button size="sm" onClick={() => setCreating((v) => !v)}>
            <Plus className="size-3.5" strokeWidth={2} />
            {creating ? "收起" : "创建共创舱"}
          </Button>
        </div>

        {creating ? (
          <form
            onSubmit={onCreate}
            className="space-y-3 rounded-xl border border-line bg-surface p-4"
          >
            <Input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="共创舱名称，例如 稀疏图上的对比学习"
              maxLength={40}
            />
            <Textarea
              value={summary}
              onChange={(e) => setSummary(e.target.value)}
              placeholder="一句话说明目标、要接入的 Agent 或数据集"
              className="min-h-20"
              maxLength={160}
            />
            <Button type="submit" disabled={!title.trim()}>
              点燃共创舱
            </Button>
          </form>
        ) : null}

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
          {pods.map((pod) => (
            <article
              key={pod.id}
              className={cn(
                "flex flex-col justify-between rounded-xl border bg-surface p-5 transition-colors duration-150",
                active?.id === pod.id
                  ? "border-neon"
                  : "border-line hover:border-line-strong",
              )}
            >
              <div>
                <div className="mb-3 flex items-center justify-between gap-2">
                  <span
                    className={cn(
                      "rounded border border-line px-2 py-0.5 font-mono text-xs",
                      pod.status === "live"
                        ? "bg-neon/10 text-neon"
                        : pod.status === "render"
                          ? "bg-volt/10 text-volt"
                          : "text-muted",
                    )}
                  >
                    {pod.statusLabel}
                  </span>
                  <span className="font-mono text-xs text-volt">{pod.id}</span>
                </div>
                <h2 className="mb-2 text-base font-bold text-fg">{pod.title}</h2>
                <p className="mb-4 text-sm leading-relaxed text-muted">
                  {pod.summary}
                </p>
              </div>
              <div>
                <div className="mb-3 flex items-center justify-between border-t border-line pt-3 font-mono text-xs text-muted">
                  <span>
                    研究员 {pod.researchers} + AI {pod.agents}
                  </span>
                  <span className={pod.status === "render" ? "text-volt" : "text-neon"}>
                    进度 {pod.progress}%
                  </span>
                </div>
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => {
                    setActive(pod);
                    push({
                      who: "System",
                      text: `已进入 ${pod.id}「${pod.title}」。`,
                      tone: "neon",
                    });
                  }}
                >
                  进入共创舱调试
                  <ArrowRight className="size-3.5" />
                </Button>
              </div>
            </article>
          ))}
        </div>

        <div className="rounded-xl border border-line bg-surface p-5">
          <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Terminal className="size-4 text-neon" strokeWidth={1.8} />
              <h2 className="text-sm font-bold">
                实时调试控制台
                {active ? ` · ${active.id}` : ""}
              </h2>
            </div>
            <span className="font-mono text-xs text-faint">
              wss://shanjitong.ai/agent/stream
            </span>
          </div>
          <div className="h-52 space-y-2 overflow-y-auto rounded-lg border border-line bg-bg p-4 font-mono text-xs">
            {logs.map((line, i) => (
              <div
                key={`${line.t}-${i}`}
                className={cn(
                  line.tone === "neon" && "text-neon",
                  line.tone === "volt" && "text-volt",
                  line.tone === "muted" && "text-muted",
                  line.tone === "faint" && "italic text-faint",
                )}
              >
                [{line.t}] {line.who}: {line.text}
              </div>
            ))}
            {busy ? <div className="text-faint">ResearchBot 推理中…</div> : null}
          </div>
          <div className="mt-3 flex gap-2">
            <Input
              value={cmd}
              onChange={(e) => setCmd(e.target.value)}
              onKeyDown={onKey}
              placeholder="输入命令（/train, /optimize, /status）或向 Agent 提问…"
              className="flex-1"
            />
            <Button
              onClick={() => void runCommand(cmd)}
              disabled={busy || !cmd.trim()}
            >
              执行指令
            </Button>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
