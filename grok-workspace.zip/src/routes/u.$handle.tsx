import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Cpu } from "lucide-react";
import { toast } from "sonner";
import { AppShell } from "@/components/shell";
import { PostCard, PostSkeleton } from "@/components/post-card";
import { UserMark } from "@/components/mark";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  getProfile,
  listUserPosts,
  toggleFollow,
  updateProfile,
} from "@/lib/social/fns";
import { useCurrentUser } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/u/$handle")({ component: ProfilePage });

function ProfilePage() {
  const { handle } = Route.useParams();
  const user = useCurrentUser();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [editing, setEditing] = useState(false);

  const profile = useQuery({
    queryKey: ["profile", handle],
    queryFn: () => getProfile({ data: { handle } }),
  });
  const posts = useQuery({
    queryKey: ["user-posts", profile.data?.userId],
    queryFn: () => listUserPosts({ data: { userId: profile.data!.userId } }),
    enabled: Boolean(profile.data?.userId),
  });

  const followMut = useMutation({
    mutationFn: () => toggleFollow({ data: { userId: profile.data!.userId } }),
    onSuccess: () => void qc.invalidateQueries(),
    onError: (err) => {
      if (err instanceof Error && err.message === "Unauthorized") {
        void navigate({ to: "/login" });
      }
    },
  });

  const p = profile.data;
  const level = p ? Math.min(9, 1 + Math.floor(p.postCount / 2) + Math.floor(p.followerCount / 3)) : 1;

  return (
    <AppShell>
      <div className="mx-auto max-w-2xl">
        {profile.isPending ? (
          <div className="h-40 animate-pulse rounded-xl bg-surface-2" />
        ) : null}
        {profile.isSuccess && !p ? (
          <div className="py-16 text-center">
            <p className="text-xl font-semibold">没有这个节点</p>
          </div>
        ) : null}
        {p ? (
          <header className="relative overflow-hidden rounded-xl border border-line bg-surface p-6">
            <div className="flex flex-col items-center gap-4 sm:flex-row sm:items-start sm:gap-6">
              <UserMark name={p.displayName} hue={p.hue} size="lg" />
              <div className="min-w-0 flex-1 text-center sm:text-left">
                <div className="flex flex-wrap items-center justify-center gap-2 sm:justify-start">
                  <h1 className="text-xl font-bold">{p.displayName}</h1>
                  <span className="rounded border border-line bg-neon/10 px-2 py-0.5 font-mono text-xs text-neon">
                    Lv.{level} 节点
                  </span>
                </div>
                <p className="mt-1 font-mono text-xs text-faint">
                  量子档案 @{p.handle}
                  {p.location ? ` · ${p.location}` : ""}
                </p>
                {p.bio ? (
                  <p className="mt-3 text-sm leading-relaxed text-muted">{p.bio}</p>
                ) : null}
                <dl className="mt-5 flex flex-wrap justify-center gap-3 sm:justify-start">
                  <Stat n={p.postCount} label="发射节点" />
                  <Stat n={p.followerCount} label="接入节点" />
                  <Stat n={p.followingCount} label="已连接" />
                </dl>
              </div>
              {p.isMe ? (
                <Button variant="outline" size="sm" onClick={() => setEditing((v) => !v)}>
                  {editing ? "收起" : "编辑档案"}
                </Button>
              ) : (
                <Button
                  variant={p.following ? "outline" : "primary"}
                  size="sm"
                  onClick={() => followMut.mutate()}
                >
                  {p.following ? "已连接" : "接入"}
                </Button>
              )}
            </div>
            {editing && p.isMe ? (
              <EditForm
                displayName={p.displayName}
                bio={p.bio}
                location={p.location}
                onDone={() => {
                  setEditing(false);
                  void qc.invalidateQueries({ queryKey: ["profile", handle] });
                }}
              />
            ) : null}
          </header>
        ) : null}

        <div className="mt-6 space-y-4">
          {posts.isPending ? <PostSkeleton /> : null}
          {posts.data?.length === 0 ? (
            <p className="py-10 text-center text-sm text-muted">
              {user?.id === p?.userId
                ? "还没有发射。去写一段神经元吧。"
                : "这个节点还很安静。"}
            </p>
          ) : null}
          {posts.data?.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      </div>
    </AppShell>
  );
}

function Stat({ n, label }: { n: number; label: string }) {
  return (
    <div className="rounded-lg border border-line bg-bg px-3 py-1.5">
      <dt className="font-mono text-xs text-faint">{label}</dt>
      <dd className="font-mono text-sm font-semibold tabular-nums text-neon">{n}</dd>
    </div>
  );
}

function EditForm({
  displayName,
  bio,
  location,
  onDone,
}: {
  displayName: string;
  bio: string;
  location: string;
  onDone: () => void;
}) {
  const [name, setName] = useState(displayName);
  const [b, setB] = useState(bio);
  const [loc, setLoc] = useState(location);
  const mut = useMutation({
    mutationFn: () =>
      updateProfile({
        data: { displayName: name, bio: b, location: loc },
      }),
    onSuccess: () => {
      toast.success("档案已同步");
      onDone();
    },
    onError: () => toast.error("没能保存"),
  });
  return (
    <form
      className="mt-6 space-y-3 border-t border-line pt-5"
      onSubmit={(e) => {
        e.preventDefault();
        mut.mutate();
      }}
    >
      <Input value={name} onChange={(e) => setName(e.target.value)} maxLength={24} />
      <Input
        value={loc}
        onChange={(e) => setLoc(e.target.value)}
        placeholder="实验室"
        maxLength={24}
      />
      <Textarea
        value={b}
        onChange={(e) => setB(e.target.value)}
        placeholder="一句话介绍"
        maxLength={120}
        className="min-h-24"
      />
      <Button type="submit" disabled={mut.isPending}>
        <Cpu className="size-3.5" />
        保存
      </Button>
    </form>
  );
}
