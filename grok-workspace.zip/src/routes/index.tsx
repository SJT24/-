import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { AppShell } from "@/components/shell";
import { PostCard, PostSkeleton } from "@/components/post-card";
import { PersonRow } from "@/components/people";
import { Composer } from "@/components/composer";
import { listFeed, listPeople } from "@/lib/social/fns";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const user = useCurrentUser();
  const [tab, setTab] = useState<"discover" | "following">("discover");
  const feed = useQuery({
    queryKey: ["feed", tab],
    queryFn: () => listFeed({ data: { tab } }),
  });
  const people = useQuery({
    queryKey: ["people-aside"],
    queryFn: () => listPeople({ data: {} }),
  });

  const suggested = (people.data ?? [])
    .filter((p) => !p.following && p.userId !== user?.id)
    .slice(0, 5);

  return (
    <AppShell
      aside={
        <div className="space-y-6">
          <section className="rounded-xl border border-line bg-surface p-4">
            <p className="font-mono text-xs uppercase tracking-wider text-faint">
              推荐节点
            </p>
            <h2 className="mt-1 text-sm font-semibold text-fg">可接入的研究员</h2>
            <div className="mt-4 space-y-4">
              {suggested.map((p) => (
                <PersonRow key={p.userId} person={p} compact />
              ))}
            </div>
            <Link
              to="/explore"
              className="mt-4 inline-block text-sm text-neon underline-offset-4 hover:underline"
            >
              打开完整图谱
            </Link>
          </section>
          <p className="font-mono text-xs leading-relaxed text-faint">
            善鸡通是去中心化极客社群。动态是神经元，共创舱是突触，档案是量子身份。
          </p>
        </div>
      }
    >
      <div className="mx-auto max-w-2xl space-y-4">
        <div className="rise-in flex flex-wrap items-center justify-between gap-3 rounded-xl border border-line bg-surface p-4">
          <div className="flex items-center gap-2">
            <span className="size-2.5 rounded-full bg-neon" />
            <h1 className="text-base font-bold tracking-wide text-fg">
              神经网络动态
            </h1>
          </div>
          <div className="flex gap-1 rounded-lg bg-bg p-1">
            <TabButton
              active={tab === "discover"}
              onClick={() => setTab("discover")}
            >
              全网图谱
            </TabButton>
            <TabButton
              active={tab === "following"}
              onClick={() => setTab("following")}
            >
              已连接
            </TabButton>
          </div>
        </div>

        <div className="rise-in-2">
          <Composer />
        </div>

        <div className="rise-in-3 space-y-4">
          {feed.isLoading ? (
            <>
              <PostSkeleton />
              <PostSkeleton />
            </>
          ) : null}
          {feed.isError && !feed.data ? (
            <p className="rounded-xl border border-line px-5 py-8 text-center text-sm text-muted">
              图谱暂时不可见。稍后重试。
            </p>
          ) : null}
          {feed.data?.length === 0 && tab === "following" && !feed.isLoading ? (
            <EmptyFollow />
          ) : null}
          {feed.data?.map((post) => (
            <PostCard key={post.id} post={post} />
          ))}
        </div>
      </div>
    </AppShell>
  );
}

function TabButton({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={cn(
        "h-10 rounded-md px-3 font-mono text-xs transition-colors duration-150",
        active
          ? "bg-surface-2 text-neon"
          : "text-muted hover:text-fg",
      )}
    >
      {children}
    </button>
  );
}

function EmptyFollow() {
  return (
    <div className="rounded-xl border border-dashed border-line px-6 py-12 text-center">
      <p className="text-lg font-semibold text-fg">连接还很安静</p>
      <p className="mt-2 text-sm text-muted">
        去节点图谱遇见研究员，动态会汇到这一边。
      </p>
      <Link
        to="/explore"
        className="mt-4 inline-block text-sm font-medium text-neon underline-offset-4 hover:underline"
      >
        打开图谱
      </Link>
    </div>
  );
}
