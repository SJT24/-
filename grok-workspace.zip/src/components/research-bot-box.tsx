import { useState, type FormEvent } from "react";
import { Terminal, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { askResearchBot } from "@/lib/ai/research-bot";

export function ResearchBotBox() {
  const [prompt, setPrompt] = useState("");
  const [reply, setReply] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    const text = prompt.trim();
    if (!text || busy) return;
    setBusy(true);
    setError(null);
    try {
      const res = await askResearchBot({ data: { prompt: text } });
      if (res.ok) {
        setReply(res.text);
        setPrompt("");
      } else {
        setError(res.error);
      }
    } catch {
      setError("无法连接 ResearchBot");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="relative overflow-hidden rounded-xl border border-line bg-surface p-4">
      <div className="mb-3 flex items-center justify-between">
        <span className="flex items-center gap-1.5 font-mono text-xs font-semibold text-volt">
          <Terminal className="size-3.5" strokeWidth={2} />
          ResearchBot 快速调用
        </span>
        <span className="font-mono text-xs text-faint">AI Agent</span>
      </div>
      <form onSubmit={onSubmit} className="space-y-2">
        <Textarea
          value={prompt}
          onChange={(e) => setPrompt(e.target.value.slice(0, 800))}
          rows={3}
          placeholder="向 ResearchBot 提问 GNN、对齐，或请求生成代码片…"
          className="min-h-20"
        />
        <div className="flex items-center justify-between gap-2">
          <span className="font-mono text-xs text-faint">Markdown / Python</span>
          <Button type="submit" size="sm" disabled={busy || !prompt.trim()}>
            {busy ? "推理中…" : "发送指令"}
            <Zap className="size-3.5" strokeWidth={2} />
          </Button>
        </div>
      </form>
      {error ? (
        <p className="mt-3 rounded-md border border-line bg-bg px-3 py-2 font-mono text-xs text-danger">
          {error}
        </p>
      ) : null}
      {reply ? (
        <pre className="mt-3 max-h-48 overflow-y-auto whitespace-pre-wrap rounded-md border border-line bg-bg px-3 py-2 font-mono text-xs leading-relaxed text-neon">
          {reply}
        </pre>
      ) : null}
    </div>
  );
}
