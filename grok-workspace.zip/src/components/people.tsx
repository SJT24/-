import { Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { UserMark } from "@/components/mark";
import { Button } from "@/components/ui/button";
import { toggleFollow } from "@/lib/social/fns";
import type { PersonCard } from "@/lib/social/types";
import { useCurrentUser } from "@/lib/auth/use-current-user";

export function PersonRow({
  person,
  compact = false,
}: {
  person: PersonCard;
  compact?: boolean;
}) {
  const user = useCurrentUser();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const isMe = user?.id === person.userId;

  const mut = useMutation({
    mutationFn: () => toggleFollow({ data: { userId: person.userId } }),
    onSuccess: () => {
      void qc.invalidateQueries();
    },
    onError: (err) => {
      if (err instanceof Error && err.message === "Unauthorized") {
        void navigate({ to: "/login" });
        return;
      }
      toast.error("未能更新连接");
    },
  });

  return (
    <div className="flex items-start gap-3">
      <Link to="/u/$handle" params={{ handle: person.handle }}>
        <UserMark
          name={person.displayName}
          hue={person.hue}
          size={compact ? "sm" : "md"}
        />
      </Link>
      <div className="min-w-0 flex-1">
        <Link
          to="/u/$handle"
          params={{ handle: person.handle }}
          className="block truncate font-medium text-fg hover:text-neon"
        >
          {person.displayName}
        </Link>
        <p className="truncate font-mono text-xs text-faint">
          @{person.handle}
          {person.location ? ` · ${person.location}` : ""}
        </p>
        {!compact && person.bio ? (
          <p className="mt-1 line-clamp-2 text-sm text-muted">{person.bio}</p>
        ) : null}
      </div>
      {isMe ? null : (
        <Button
          variant={person.following ? "outline" : "primary"}
          size="sm"
          onClick={() => mut.mutate()}
        >
          {person.following ? "已连接" : "接入"}
        </Button>
      )}
    </div>
  );
}
