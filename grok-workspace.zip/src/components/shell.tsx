import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  Bell,
  Compass,
  Cpu,
  Menu,
  Network,
  PenLine,
  Search,
  UserRound,
  X,
} from "lucide-react";
import { NeuralMark, UserMark } from "@/components/mark";
import { ResearchBotBox } from "@/components/research-bot-box";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SignedIn, SignedOut, UserButton } from "@/lib/auth/gates";
import { useCurrentUser, useCurrentUserState } from "@/lib/auth/use-current-user";
import { clusterStats, ensureProfile, myProfile, unreadCount } from "@/lib/social/fns";
import { usePodStore } from "@/lib/social/pods";
import { cn } from "@/lib/utils";

const NAV = [
  { to: "/", label: "神经网络", icon: Network, match: (p: string) => p === "/" },
  {
    to: "/pods",
    label: "AI 共创舱",
    icon: Cpu,
    match: (p: string) => p.startsWith("/pods"),
  },
  {
    to: "/explore",
    label: "节点图谱",
    icon: Compass,
    match: (p: string) => p.startsWith("/explore"),
  },
  {
    to: "/notifications",
    label: "突触通知",
    icon: Bell,
    match: (p: string) => p.startsWith("/notifications"),
  },
] as const;

export function AppShell({
  children,
  aside,
}: {
  children: ReactNode;
  aside?: ReactNode;
}) {
  const { user, isPending } = useCurrentUserState();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [handle, setHandle] = useState<string | null>(null);
  const [drawer, setDrawer] = useState(false);
  const [q, setQ] = useState("");
  const navigate = useNavigate();
  const livePods = usePodStore((s) => s.pods.filter((p) => p.status !== "idle").length);

  useEffect(() => {
    if (!user) return;
    let alive = true;
    ensureProfile({ data: { displayName: user.displayName ?? undefined } })
      .then((r) => {
        if (alive) setHandle(r.handle);
      })
      .catch(() => undefined);
    return () => {
      alive = false;
    };
  }, [user]);

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        const el = document.getElementById("global-search");
        if (el) el.focus();
        else void navigate({ to: "/explore" });
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [navigate]);

  const unread = useQuery({
    queryKey: ["unread"],
    queryFn: () => unreadCount(),
    enabled: Boolean(user),
    refetchInterval: 30_000,
  });

  const stats = useQuery({
    queryKey: ["cluster-stats"],
    queryFn: () => clusterStats(),
  });

  function submitSearch(e: FormEvent) {
    e.preventDefault();
    void navigate({ to: "/explore", search: { q: q.trim() } });
    setDrawer(false);
  }

  return (
    <div className="bg-grid min-h-dvh">
      <header className="sticky top-0 z-40 border-b border-line bg-surface/90 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 lg:px-8">
          <button
            type="button"
            className="inline-flex size-11 items-center justify-center rounded-md border border-line bg-bg text-muted lg:hidden"
            onClick={() => setDrawer(true)}
            aria-label="打开导航"
          >
            <Menu className="size-4" strokeWidth={1.8} />
          </button>
          <Brand />
          <form
            onSubmit={submitSearch}
            className="mx-auto hidden min-w-0 flex-1 items-center md:flex md:max-w-md lg:max-w-lg"
          >
            <label className="flex h-11 w-full items-center gap-2 rounded-full border border-line bg-bg px-4 focus-within:border-neon">
              <Search className="size-3.5 shrink-0 text-faint" strokeWidth={1.8} />
              <input
                id="global-search"
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="搜索节点、Agent 或代码图谱…"
                className="min-w-0 flex-1 bg-transparent font-mono text-xs text-fg outline-none placeholder:text-faint"
              />
              <span className="hidden rounded border border-line bg-surface-2 px-1.5 py-0.5 font-mono text-xs text-neon sm:inline">
                ⌘K
              </span>
            </label>
          </form>
          <div className="ml-auto flex items-center gap-2">
            <div className="hidden items-center gap-2 rounded-full border border-line bg-surface-2 px-3 py-1 font-mono text-xs xl:flex">
              <span className="size-2 rounded-full bg-neon" />
              <span className="text-neon">ResearchBot v4.2 协同中</span>
            </div>
            <Link
              to="/notifications"
              className="relative inline-flex size-11 items-center justify-center rounded-md border border-line bg-bg text-muted hover:text-neon"
              aria-label="通知"
            >
              <Bell className="size-4" strokeWidth={1.8} />
              {unread.data ? (
                <span className="absolute top-2 right-2 size-2 rounded-full bg-volt" />
              ) : null}
            </Link>
            <SignedOut>
              <Link to="/login">
                <Button size="sm">接入</Button>
              </Link>
            </SignedOut>
            <SignedIn>
              <button
                type="button"
                onClick={() => {
                  if (handle) {
                    void navigate({ to: "/u/$handle", params: { handle } });
                  }
                }}
                className="flex items-center gap-2 border-l border-line pl-2"
              >
                <UserMark
                  name={user?.displayName ?? "节"}
                  hue={140}
                  size="sm"
                />
                <span className="hidden text-left sm:block">
                  <span className="block text-xs font-semibold text-fg">
                    {user?.displayName ?? "节点"}
                  </span>
                  <span className="block font-mono text-xs text-neon">
                    {handle ? `@${handle}` : "量子档案"}
                  </span>
                </span>
              </button>
            </SignedIn>
          </div>
        </div>
      </header>

      {drawer ? (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            type="button"
            className="absolute inset-0 bg-hero-ink/80"
            aria-label="关闭导航"
            onClick={() => setDrawer(false)}
          />
          <div className="relative flex h-full w-72 flex-col border-r border-line bg-surface p-5">
            <div className="mb-5 flex items-center justify-between border-b border-line pb-4">
              <Brand compact />
              <button
                type="button"
                className="inline-flex size-11 items-center justify-center text-muted"
                onClick={() => setDrawer(false)}
                aria-label="关闭"
              >
                <X className="size-5" />
              </button>
            </div>
            <form onSubmit={submitSearch} className="mb-4">
              <Input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="搜索节点…"
                aria-label="搜索"
              />
            </form>
            <nav className="flex flex-1 flex-col gap-1">
              {NAV.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  onClick={() => setDrawer(false)}
                  className={cn(
                    "flex h-11 items-center gap-3 rounded-lg px-3 text-sm",
                    item.match(pathname)
                      ? "border border-line bg-neon/10 text-neon"
                      : "text-muted hover:bg-surface-2 hover:text-neon",
                  )}
                >
                  <item.icon className="size-4" strokeWidth={1.8} />
                  {item.label}
                </Link>
              ))}
            </nav>
            <p className="border-t border-line pt-4 font-mono text-xs text-faint">
              ShanJiTong v2.6 · Neural Ecosystem
            </p>
          </div>
        </div>
      ) : null}

      <div className="mx-auto grid max-w-7xl grid-cols-1 gap-6 px-4 py-6 lg:grid-cols-12 lg:px-8">
        <aside className="hidden space-y-4 lg:col-span-3 lg:block">
          <div className="glow-live rounded-xl border border-line bg-surface p-4 shadow-soft">
            <div className="mb-3 px-3 font-mono text-xs uppercase tracking-wider text-faint">
              核心路由
            </div>
            <nav className="space-y-1">
              {NAV.map((item) => (
                <NavLink
                  key={item.to}
                  to={item.to}
                  label={item.label}
                  icon={item.icon}
                  active={item.match(pathname)}
                  badge={
                    item.to === "/notifications"
                      ? unread.data
                      : item.to === "/pods"
                        ? livePods
                        : undefined
                  }
                  badgeTone={item.to === "/pods" ? "volt" : "neon"}
                />
              ))}
              <MeLink handle={handle} active={pathname.startsWith("/u/")} />
              <SignedIn>
                <Link to="/compose" className="mt-3 block">
                  <Button className="w-full" size="lg">
                    <PenLine className="size-4" strokeWidth={1.75} />
                    发射节点
                  </Button>
                </Link>
              </SignedIn>
            </nav>
          </div>

          <ResearchBotBox />

          <div className="space-y-3 rounded-xl border border-line bg-surface p-4 text-xs">
            <div className="font-mono text-xs uppercase tracking-wider text-faint">
              集群运行状态
            </div>
            <div className="flex items-center justify-between font-mono">
              <span className="text-muted">活跃神经网络节点</span>
              <span className="font-bold tabular-nums text-neon">
                {(stats.data?.nodes ?? 0).toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between font-mono">
              <span className="text-muted">已发射神经元</span>
              <span className="font-bold tabular-nums text-volt">
                {(stats.data?.sparks ?? 0).toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between font-mono">
              <span className="text-muted">突触讨论</span>
              <span className="font-bold tabular-nums text-fg">
                {(stats.data?.links ?? 0).toLocaleString()}
              </span>
            </div>
            <div className="mt-1 h-1.5 overflow-hidden rounded-full border border-line bg-bg">
              <div className="bg-signal h-full w-4/5" />
            </div>
          </div>

          <AuthCorner handle={handle} pending={isPending} />
        </aside>

        <div className="min-w-0 lg:col-span-9">
          <div className="flex min-w-0 gap-6 pb-20 lg:pb-0">
            <main className="min-w-0 flex-1">{children}</main>
            {aside ? (
              <aside className="sticky top-24 hidden h-[calc(100dvh-7rem)] w-72 shrink-0 overflow-y-auto xl:block">
                {aside}
              </aside>
            ) : null}
          </div>
        </div>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-line bg-surface/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-sm lg:hidden">
        {NAV.slice(0, 3).map((item) => (
          <Link
            key={item.to}
            to={item.to}
            className={cn(
              "relative flex h-14 flex-col items-center justify-center gap-0.5 text-xs",
              item.match(pathname) ? "text-neon" : "text-muted",
            )}
          >
            <item.icon className="size-5" strokeWidth={1.7} />
            {item.label.replace("神经网络", "动态").replace("AI 共创舱", "共创舱").replace("节点图谱", "图谱")}
          </Link>
        ))}
        <Link
          to="/notifications"
          className={cn(
            "relative flex h-14 flex-col items-center justify-center gap-0.5 text-xs",
            pathname.startsWith("/notifications") ? "text-neon" : "text-muted",
          )}
        >
          <Bell className="size-5" strokeWidth={1.7} />
          通知
          {unread.data ? (
            <span className="absolute top-1.5 right-6 size-1.5 rounded-full bg-volt" />
          ) : null}
        </Link>
        <MeLink handle={handle} active={pathname.startsWith("/u/")} mobile />
      </nav>
    </div>
  );
}

function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <NeuralMark className="size-10" />
      <span className="min-w-0">
        <span className="text-signal block text-sm font-bold tracking-wider">
          SHAN JI TONG
        </span>
        {compact ? null : (
          <span className="hidden font-mono text-xs tracking-widest text-faint uppercase sm:block">
            善鸡通 · 神经网络社群
          </span>
        )}
      </span>
    </Link>
  );
}

function NavLink({
  to,
  label,
  icon: Icon,
  active,
  badge,
  badgeTone = "neon",
}: {
  to: "/" | "/explore" | "/notifications" | "/pods";
  label: string;
  icon: typeof Network;
  active: boolean;
  badge?: number;
  badgeTone?: "neon" | "volt";
}) {
  return (
    <Link
      to={to}
      className={cn(
        "relative flex h-11 items-center gap-3 rounded-lg px-3 text-sm transition-colors duration-150",
        active
          ? "border border-line bg-neon/10 font-semibold text-neon"
          : "text-muted hover:bg-surface-2 hover:text-neon",
      )}
    >
      <Icon className="size-4" strokeWidth={1.7} />
      {label}
      {badge ? (
        <span
          className={cn(
            "ml-auto rounded px-1.5 py-0.5 font-mono text-xs",
            badgeTone === "volt"
              ? "bg-volt/15 text-volt"
              : "size-2 rounded-full bg-neon p-0",
          )}
        >
          {badgeTone === "volt" ? `${badge} 活跃` : null}
        </span>
      ) : null}
    </Link>
  );
}

function MeLink({
  handle,
  active,
  mobile = false,
}: {
  handle: string | null;
  active: boolean;
  mobile?: boolean;
}) {
  const user = useCurrentUser();
  if (!user) {
    if (mobile) {
      return (
        <Link
          to="/login"
          className="flex h-14 flex-col items-center justify-center gap-0.5 text-xs text-muted"
        >
          <UserRound className="size-5" strokeWidth={1.7} />
          档案
        </Link>
      );
    }
    return null;
  }
  if (mobile) {
    if (!handle) {
      return (
        <Link
          to="/login"
          className="flex h-14 flex-col items-center justify-center gap-0.5 text-xs text-muted"
        >
          <UserRound className="size-5" strokeWidth={1.7} />
          档案
        </Link>
      );
    }
    return (
      <Link
        to="/u/$handle"
        params={{ handle }}
        className={cn(
          "flex h-14 flex-col items-center justify-center gap-0.5 text-xs",
          active ? "text-neon" : "text-muted",
        )}
      >
        <UserRound className="size-5" strokeWidth={1.7} />
        档案
      </Link>
    );
  }
  if (!handle) {
    return (
      <span className="flex h-11 items-center gap-3 rounded-lg px-3 text-sm text-muted">
        <UserRound className="size-4" strokeWidth={1.7} />
        量子档案
      </span>
    );
  }
  return (
    <Link
      to="/u/$handle"
      params={{ handle }}
      className={cn(
        "flex h-11 items-center gap-3 rounded-lg px-3 text-sm transition-colors duration-150",
        active
          ? "border border-line bg-neon/10 font-semibold text-neon"
          : "text-muted hover:bg-surface-2 hover:text-neon",
      )}
    >
      <UserRound className="size-4" strokeWidth={1.7} />
      量子档案
    </Link>
  );
}

function AuthCorner({
  handle,
  pending,
}: {
  handle: string | null;
  pending: boolean;
}) {
  const user = useCurrentUser();
  const mine = useQuery({
    queryKey: ["me-profile"],
    queryFn: () => myProfile(),
    enabled: Boolean(user),
  });
  const shownHandle = handle ?? mine.data?.handle ?? null;

  if (pending) {
    return <div className="h-12 w-full animate-pulse rounded-md bg-surface-2" />;
  }
  if (!user) {
    return (
      <Link to="/login">
        <Button variant="outline" className="w-full">
          接入善鸡通
        </Button>
      </Link>
    );
  }
  return (
    <div className="rounded-lg border border-line bg-surface-2/60 p-3">
      <div className="flex items-center gap-2">
        <UserMark
          name={user.displayName ?? shownHandle ?? "节"}
          hue={140}
          size="sm"
        />
        <div className="min-w-0">
          <p className="truncate text-sm font-medium">
            {user.displayName ?? "节点"}
          </p>
          {shownHandle ? (
            <p className="truncate font-mono text-xs text-faint">@{shownHandle}</p>
          ) : null}
        </div>
      </div>
      <div className="mt-2 text-xs text-muted">
        <UserButton />
      </div>
    </div>
  );
}
