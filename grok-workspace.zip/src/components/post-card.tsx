import { Link, useNavigate } from "@tanstack/react-router";
import { Bookmark, Heart, MessageCircle, Share2, Trash2 } from "lucide-react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { UserMark } from "@/components/mark";
import { PostBody } from "@/lib/social/post-body";
import { deletePost, toggleLike } from "@/lib/social/fns";
import { fromNow } from "@/lib/social/time";
import type { PostItem } from "@/lib/social/types";
import { cn } from "@/lib/utils";
import { useCurrentUser } from "@/lib/auth/use-current-user";

export function PostCard({
  post,
  compact = false,
}: {
  post: PostItem;
  compact?: boolean;
}) {
  const user = useCurrentUser();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const isMine = Boolean(user && user.id === post.author.userId);
  const highlighted =
    post.author.handle === "researchbot" || /GNN|Agent|对齐/.test(post.body);

  const likeMut = useMutation({
    mutationFn: () => toggleLike({ data: { postId: post.id } }),
    onSuccess: () => {
      void qc.invalidateQueries();
    },
    onError: (err) => {
      if (err instanceof Error && err.message === "Unauthorized") {
        void navigate({ to: "/login" });
        return;
      }
      toast.error("未能同步权重");
    },
  });

  const delMut = useMutation({
    mutationFn: () => deletePost({ data: { id: post.id } }),
    onSuccess: () => {
      toast.success("节点已回收");
      void qc.invalidateQueries();
    },
  });

  return (
    <article className="relative overflow-hidden rounded-xl border border-line bg-surface p-5 transition-colors duration-150 hover:border-line-strong">
      {highlighted && !compact ? (
        <div className="absolute top-0 right-0 rounded-bl-lg border-b border-l border-line bg-neon/10 px-3 py-1 font-mono text-xs text-neon">
          AI 智能高亮
        </div>
      ) : null}
      <div className="flex items-start gap-3">
        <Link to="/u/$handle" params={{ handle: post.author.handle }}>
          <UserMark name={post.author.displayName} hue={post.author.hue} />
        </Link>
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-2">
            <Link
              to="/u/$handle"
              params={{ handle: post.author.handle }}
              className="truncate font-semibold text-fg hover:text-neon"
            >
              {post.author.displayName}
            </Link>
            <span className="rounded border border-line bg-surface-2 px-1.5 py-0.5 font-mono text-xs text-volt">
              @{post.author.handle}
            </span>
            <span className="ml-auto shrink-0 font-mono text-xs tabular-nums text-faint">
              {fromNow(post.createdAt)}
            </span>
          </div>
          <Link
            to="/p/$id"
            params={{ id: String(post.id) }}
            className="mt-3 block"
          >
            <PostBody text={post.body} />
          </Link>
          {post.place ? (
            <p className="mt-3 font-mono text-xs text-muted">{post.place}</p>
          ) : null}
          <div className="mt-3 flex items-center gap-1 border-t border-line/80 pt-2">
            <button
              type="button"
              onClick={() => likeMut.mutate()}
              className={cn(
                "inline-flex h-10 items-center gap-1.5 rounded-md px-2.5 text-sm transition-colors duration-150",
                post.liked
                  ? "text-neon"
                  : "text-muted hover:bg-surface-2 hover:text-neon",
              )}
              aria-pressed={post.liked}
            >
              <Heart
                className="size-4"
                strokeWidth={1.75}
                fill={post.liked ? "currentColor" : "none"}
              />
              <span className="font-mono tabular-nums">{post.likeCount}</span>
            </button>
            <Link
              to="/p/$id"
              params={{ id: String(post.id) }}
              className="inline-flex h-10 items-center gap-1.5 rounded-md px-2.5 text-sm text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-volt"
            >
              <MessageCircle className="size-4" strokeWidth={1.75} />
              <span className="font-mono tabular-nums">{post.commentCount}</span>
            </Link>
            <button
              type="button"
              onClick={() => toast.success("已同步至量子档案")}
              className="inline-flex h-10 items-center gap-1.5 rounded-md px-2.5 text-sm text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-neon"
            >
              <Share2 className="size-4" strokeWidth={1.75} />
            </button>
            <button
              type="button"
              onClick={() => toast.success("已加入收藏夹")}
              className="inline-flex size-10 items-center justify-center rounded-md text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-volt"
              aria-label="收藏"
            >
              <Bookmark className="size-4" strokeWidth={1.75} />
            </button>
            {isMine ? (
              <button
                type="button"
                onClick={() => delMut.mutate()}
                className="ml-auto inline-flex size-10 items-center justify-center rounded-md text-faint transition-colors duration-150 hover:bg-surface-2 hover:text-danger"
                aria-label="删除"
              >
                <Trash2 className="size-4" strokeWidth={1.75} />
              </button>
            ) : null}
          </div>
        </div>
      </div>
    </article>
  );
}

export function PostSkeleton() {
  return (
    <div className="overflow-hidden rounded-xl border border-line bg-surface p-5">
      <div className="flex gap-3">
        <div className="size-10 animate-pulse rounded-lg bg-surface-2" />
        <div className="flex-1 space-y-3">
          <div className="h-4 w-1/3 animate-pulse rounded bg-surface-2" />
          <div className="h-4 w-full animate-pulse rounded bg-surface-2" />
          <div className="h-4 w-2/3 animate-pulse rounded bg-surface-2" />
        </div>
      </div>
    </div>
  );
}
