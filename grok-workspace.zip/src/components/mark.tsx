import { cn } from "@/lib/utils";

export function NeuralMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-8", className)}
      aria-hidden
    >
      <rect width="32" height="32" rx="8" className="fill-bg" />
      <rect
        x="0.6"
        y="0.6"
        width="30.8"
        height="30.8"
        rx="7.4"
        className="stroke-neon"
        strokeWidth="1.2"
        fill="none"
      />
      <circle cx="10" cy="11" r="2.1" className="fill-neon" />
      <circle cx="22" cy="10" r="1.7" className="fill-volt" />
      <circle cx="16" cy="17" r="2.4" className="fill-neon" />
      <circle cx="9" cy="22" r="1.6" className="fill-volt" />
      <circle cx="23" cy="22" r="1.9" className="fill-neon" />
      <path
        d="M10 11 L16 17 L22 10 M16 17 L9 22 M16 17 L23 22"
        className="stroke-neon"
        strokeWidth="1.15"
        fill="none"
        strokeLinecap="round"
        opacity="0.85"
      />
    </svg>
  );
}

export function UserMark({
  name,
  hue,
  size = "md",
}: {
  name: string;
  hue: number;
  size?: "sm" | "md" | "lg";
}) {
  const ch = (name.trim().charAt(0) || "节").toUpperCase();
  const dim =
    size === "sm"
      ? "size-8 text-xs"
      : size === "lg"
        ? "size-20 text-2xl"
        : "size-10 text-sm";
  const inner =
    size === "sm" ? "rounded-sm" : size === "lg" ? "rounded-lg" : "rounded-md";
  const volt = hue % 2 === 0;
  return (
    <span
      className={cn(
        "grid shrink-0 place-items-center rounded-lg bg-signal p-px",
        dim,
      )}
      aria-hidden
    >
      <span
        className={cn(
          "grid size-full place-items-center bg-bg font-mono font-semibold",
          inner,
          volt ? "text-volt" : "text-neon",
        )}
      >
        {ch}
      </span>
    </span>
  );
}
