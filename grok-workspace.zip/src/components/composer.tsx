import { useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Code2, Cpu, Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { UserMark } from "@/components/mark";
import { createPost } from "@/lib/social/fns";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { SignedIn, SignedOut } from "@/lib/auth/gates";
import { cn } from "@/lib/utils";

const SNIPPET = `\`\`\`py
import torch
def message_pass(x, adj):
    return adj @ x
\`\`\``;

export function Composer({ compact = false }: { compact?: boolean }) {
  const user = useCurrentUser();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [body, setBody] = useState("");
  const [place, setPlace] = useState("");

  const mut = useMutation({
    mutationFn: () =>
      createPost({
        data: { body: body.trim(), imageKey: null, place: place.trim() },
      }),
    onSuccess: async () => {
      toast.success("神经元已发射");
      setBody("");
      setPlace("");
      await qc.invalidateQueries();
    },
    onError: (err) => {
      if (err instanceof Error && err.message === "Unauthorized") {
        void navigate({ to: "/login" });
        return;
      }
      toast.error(err instanceof Error ? err.message : "发射失败");
    },
  });

  const remaining = 1200 - body.length;

  return (
    <div className="rounded-xl border border-line bg-surface p-4 shadow-soft">
      <SignedOut>
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm text-muted">
            接入节点后即可向神经网络发射动态。
          </p>
          <Link to="/login">
            <Button size="sm">接入</Button>
          </Link>
        </div>
      </SignedOut>
      <SignedIn>
        <div className="flex gap-3">
          <UserMark
            name={user?.displayName ?? "节"}
            hue={140}
            size={compact ? "sm" : "md"}
          />
          <form
            className="min-w-0 flex-1 space-y-3"
            onSubmit={(e) => {
              e.preventDefault();
              if (!body.trim()) {
                toast.error("写一句再发射");
                return;
              }
              mut.mutate();
            }}
          >
            <Textarea
              value={body}
              onChange={(e) => setBody(e.target.value.slice(0, 1200))}
              placeholder="发布研究灵感、架构图谱或代码片段… 可 @ResearchBot"
              className={cn("min-h-24", compact && "min-h-20")}
            />
            <Input
              value={place}
              onChange={(e) => setPlace(e.target.value.slice(0, 40))}
              placeholder="图谱 / 实验室（可空） 例如 GNN Lab"
              className="h-10"
            />
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div className="flex items-center gap-1">
                <button
                  type="button"
                  onClick={() =>
                    setBody((b) => (b.includes("```") ? b : `${b}\n${SNIPPET}`.trim()))
                  }
                  className="inline-flex size-10 items-center justify-center rounded-md text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-neon"
                  aria-label="插入代码片段"
                >
                  <Code2 className="size-4" strokeWidth={1.75} />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setPlace((p) => p || "共创舱 · 联合调试")
                  }
                  className="inline-flex size-10 items-center justify-center rounded-md text-muted transition-colors duration-150 hover:bg-surface-2 hover:text-volt"
                  aria-label="标记共创舱"
                >
                  <Cpu className="size-4" strokeWidth={1.75} />
                </button>
                <span
                  className={cn(
                    "px-2 font-mono text-xs tabular-nums text-faint",
                    remaining < 40 && "text-danger",
                  )}
                >
                  {remaining}
                </span>
              </div>
              <Button type="submit" size="sm" disabled={mut.isPending}>
                {mut.isPending ? "发射中…" : "发射神经元"}
                <Send className="size-3.5" strokeWidth={2} />
              </Button>
            </div>
          </form>
        </div>
      </SignedIn>
    </div>
  );
}
