import { type InputHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

export const Input = forwardRef<
  HTMLInputElement,
  InputHTMLAttributes<HTMLInputElement>
>(function Input({ className, ...props }, ref) {
  return (
    <input
      ref={ref}
      className={cn(
        "h-11 w-full rounded-md border border-line bg-bg px-3.5 text-sm text-fg placeholder:text-faint",
        "font-mono transition-[border-color,box-shadow] duration-150",
        "focus-visible:border-neon focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon/30",
        className,
      )}
      {...props}
    />
  );
});
