import { type TextareaHTMLAttributes, forwardRef } from "react";
import { cn } from "@/lib/utils";

export const Textarea = forwardRef<
  HTMLTextAreaElement,
  TextareaHTMLAttributes<HTMLTextAreaElement>
>(function Textarea({ className, ...props }, ref) {
  return (
    <textarea
      ref={ref}
      className={cn(
        "min-h-32 w-full rounded-lg border border-line bg-bg px-3.5 py-3 text-sm leading-relaxed text-fg placeholder:text-faint",
        "font-mono transition-[border-color,box-shadow] duration-150",
        "focus-visible:border-neon focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon/30",
        className,
      )}
      {...props}
    />
  );
});
