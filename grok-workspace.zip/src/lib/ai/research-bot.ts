import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const SYSTEM = `你是善鸡通（SHAN JI TONG）的 ResearchBot，神经网络与去中心化极客社群的协同 Agent。
用简洁、专业的中文回答。必要时给出可运行的短代码。关注 GNN、大模型对齐、向量检索、分布式训练与模型防御。
不要编造不存在的论文数据或基准分数。回复控制在 350 字以内。`;

let windowStart = Date.now();
let callCount = 0;

function allowCall(): boolean {
  const now = Date.now();
  if (now - windowStart > 60_000) {
    windowStart = now;
    callCount = 0;
  }
  if (callCount >= 20) return false;
  callCount += 1;
  return true;
}

export const askResearchBot = createServerFn({ method: "POST" })
  .validator(
    z.object({
      prompt: z.string().min(1).max(800),
      context: z.string().max(240).optional(),
    }),
  )
  .handler(async ({ data }) => {
    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      return { ok: false as const, error: "ResearchBot 当前未接入算力节点" };
    }
    if (!allowCall()) {
      return { ok: false as const, error: "指令过密，稍后再试" };
    }

    const userContent = data.context
      ? `【共创舱上下文】${data.context}\n\n${data.prompt}`
      : data.prompt;

    try {
      const res = await fetch("https://api.x.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "grok-4.5",
          max_tokens: 700,
          messages: [
            { role: "system", content: SYSTEM },
            { role: "user", content: userContent },
          ],
        }),
      });
      if (!res.ok) {
        return { ok: false as const, error: `节点响应异常 ${res.status}` };
      }
      const body = (await res.json()) as {
        choices: { message: { content: string } }[];
      };
      const text = body.choices[0]?.message.content?.trim() ?? "";
      if (!text) return { ok: false as const, error: "空响应" };
      return { ok: true as const, text };
    } catch {
      return { ok: false as const, error: "无法连接 ResearchBot" };
    }
  });
