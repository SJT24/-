import { create } from "zustand";

export type Pod = {
  id: string;
  title: string;
  summary: string;
  status: "live" | "render" | "idle";
  statusLabel: string;
  progress: number;
  researchers: number;
  agents: number;
};

export const SEED_PODS: Pod[] = [
  {
    id: "POD-8801",
    title: "向量数据库与图神经网络加速",
    summary:
      "多 Agent 协同优化高维向量检索速度，已集成 ResearchBot 与 CodeAgent 双引擎自动生成测试用例。",
    status: "live",
    statusLabel: "实时调试中",
    progress: 84,
    researchers: 8,
    agents: 2,
  },
  {
    id: "POD-8802",
    title: "极客视觉 VI 与电路板神经元生成",
    summary:
      "探索黑客绿与电光黄美学极限，结合 SVG 与神经网络图腾实时渲染品牌视觉与交互界面。",
    status: "render",
    statusLabel: "多模态渲染",
    progress: 92,
    researchers: 12,
    agents: 3,
  },
  {
    id: "POD-8803",
    title: "大模型对齐与去中心化评测",
    summary:
      "把对齐评测拆成可验证的节点任务。每个研究员提交一条对抗样本，集群汇总漂移曲线。",
    status: "live",
    statusLabel: "联合评测",
    progress: 61,
    researchers: 19,
    agents: 4,
  },
  {
    id: "POD-8804",
    title: "量子密码学与模型防御机制",
    summary:
      "在权重分发层加入可验证随机数与差分隐私噪声，防止共创舱模型被梯度反演。",
    status: "idle",
    statusLabel: "等待接入",
    progress: 37,
    researchers: 6,
    agents: 2,
  },
];

type PodStore = {
  pods: Pod[];
  addPod: (input: { title: string; summary: string }) => Pod;
};

export const usePodStore = create<PodStore>((set, get) => ({
  pods: SEED_PODS,
  addPod: ({ title, summary }) => {
    const n = 8800 + get().pods.length + 1;
    const pod: Pod = {
      id: `POD-${n}`,
      title,
      summary,
      status: "live",
      statusLabel: "刚刚点燃",
      progress: 8,
      researchers: 1,
      agents: 1,
    };
    set({ pods: [pod, ...get().pods] });
    return pod;
  },
}));
