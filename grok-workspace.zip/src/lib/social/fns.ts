import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { optionalAuth } from "./optional-auth";
import { isImageKey } from "./images";
import { asBool, asInt, iso } from "@/lib/utils";
import type {
  Author,
  CommentItem,
  NoticeItem,
  PersonCard,
  PostItem,
  ProfilePublic,
} from "./types";

type PostRow = {
  id: number;
  body: string;
  image_key: string | null;
  place: string;
  created_at: unknown;
  author_id: string;
  handle: string;
  display_name: string;
  hue: number;
  like_count: unknown;
  comment_count: unknown;
  liked: unknown;
};

function handleBase(name: string, userId: string): string {
  const latin = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "")
    .slice(0, 14);
  if (latin.length >= 2) return latin;
  const tail = userId.replace(/[^a-zA-Z0-9]/g, "").slice(-6).toLowerCase();
  return `node${tail || "ke"}`;
}

async function uniqueHandle(
  sql: Awaited<ReturnType<typeof getSql>>,
  base: string,
): Promise<string> {
  const cleaned = base.replace(/[^a-z0-9]/g, "").slice(0, 18) || "node";
  for (let i = 0; i < 40; i += 1) {
    const candidate = i === 0 ? cleaned : `${cleaned}${i + 1}`.slice(0, 22);
    const rows = await sql<{ n: number }>`
      select 1 as n from profiles where handle = ${candidate} limit 1
    `;
    if (rows.length === 0) return candidate;
  }
  return `${cleaned}${Date.now().toString(36).slice(-4)}`;
}

function mapPost(row: PostRow): PostItem {
  return {
    id: asInt(row.id),
    body: row.body,
    imageKey: isImageKey(row.image_key) ? row.image_key : null,
    place: row.place ?? "",
    createdAt: iso(row.created_at),
    author: {
      userId: row.author_id,
      handle: row.handle,
      displayName: row.display_name,
      hue: asInt(row.hue),
    },
    likeCount: asInt(row.like_count),
    commentCount: asInt(row.comment_count),
    liked: asBool(row.liked),
  };
}

async function ensureRow(
  sql: Awaited<ReturnType<typeof getSql>>,
  userId: string,
) {
  const existing = await sql<{ n: number }>`
    select 1 as n from profiles where user_id = ${userId} limit 1
  `;
  if (existing.length) return;
  const name = "节点";
  const handle = await uniqueHandle(sql, handleBase(name, userId));
  const hue =
    Math.abs([...userId].reduce((a, ch) => a + ch.charCodeAt(0), 0)) % 360;
  await sql`
    insert into profiles (user_id, handle, display_name, hue)
    values (${userId}, ${handle}, ${name}, ${hue})
    on conflict (user_id) do nothing
  `;
}

export const ensureProfile = createServerFn({ method: "POST" })
  .validator(
    z.object({
      displayName: z.string().max(40).optional(),
    }),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const existing = await sql<{ handle: string }>`
      select handle from profiles where user_id = ${context.userId} limit 1
    `;
    if (existing[0]) return { handle: existing[0].handle, created: false };

    const name = (data.displayName?.trim() || "节点").slice(0, 24);
    const handle = await uniqueHandle(sql, handleBase(name, context.userId));
    const hue = Math.abs(
      [...context.userId].reduce((a, ch) => a + ch.charCodeAt(0), 0),
    ) % 360;

    await sql`
      insert into profiles (user_id, handle, display_name, hue)
      values (${context.userId}, ${handle}, ${name}, ${hue})
    `;
    return { handle, created: true };
  });

export const listFeed = createServerFn({ method: "GET" })
  .validator(
    z.object({
      tab: z.enum(["discover", "following"]),
    }),
  )
  .middleware([optionalAuth])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = context.userId;
    const likedParam = me ?? "__none__";

    if (data.tab === "following") {
      if (!me) return [] as PostItem[];
      const rows = await sql<PostRow>`
        select
          p.id,
          p.body,
          p.image_key,
          p.place,
          p.created_at,
          pr.user_id as author_id,
          pr.handle,
          pr.display_name,
          pr.hue,
          (select count(*)::int from likes l where l.post_id = p.id) as like_count,
          (select count(*)::int from comments c where c.post_id = p.id) as comment_count,
          exists(select 1 from likes lx where lx.post_id = p.id and lx.user_id = ${me}) as liked
        from posts p
        join profiles pr on pr.user_id = p.user_id
        where p.user_id = ${me}
           or p.user_id in (select followee_id from follows where follower_id = ${me})
        order by p.created_at desc
        limit 40
      `;
      return rows.map(mapPost);
    }

    const rows = await sql<PostRow>`
      select
        p.id,
        p.body,
        p.image_key,
        p.place,
        p.created_at,
        pr.user_id as author_id,
        pr.handle,
        pr.display_name,
        pr.hue,
        (select count(*)::int from likes l where l.post_id = p.id) as like_count,
        (select count(*)::int from comments c where c.post_id = p.id) as comment_count,
        exists(select 1 from likes lx where lx.post_id = p.id and lx.user_id = ${likedParam}) as liked
      from posts p
      join profiles pr on pr.user_id = p.user_id
      order by p.created_at desc
      limit 40
    `;
    return rows.map(mapPost);
  });

export const getPost = createServerFn({ method: "GET" })
  .validator(z.object({ id: z.number() }))
  .middleware([optionalAuth])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const likedParam = context.userId ?? "__none__";
    const rows = await sql<PostRow>`
      select
        p.id,
        p.body,
        p.image_key,
        p.place,
        p.created_at,
        pr.user_id as author_id,
        pr.handle,
        pr.display_name,
        pr.hue,
        (select count(*)::int from likes l where l.post_id = p.id) as like_count,
        (select count(*)::int from comments c where c.post_id = p.id) as comment_count,
        exists(select 1 from likes lx where lx.post_id = p.id and lx.user_id = ${likedParam}) as liked
      from posts p
      join profiles pr on pr.user_id = p.user_id
      where p.id = ${data.id}
      limit 1
    `;
    return rows[0] ? mapPost(rows[0]) : null;
  });

export const listComments = createServerFn({ method: "GET" })
  .validator(z.object({ postId: z.number() }))
  .handler(async ({ data }) => {
    const sql = await getSql();
    const rows = await sql<{
      id: number;
      body: string;
      created_at: unknown;
      user_id: string;
      handle: string;
      display_name: string;
      hue: number;
    }>`
      select
        c.id, c.body, c.created_at,
        pr.user_id, pr.handle, pr.display_name, pr.hue
      from comments c
      join profiles pr on pr.user_id = c.user_id
      where c.post_id = ${data.postId}
      order by c.created_at asc
      limit 80
    `;
    return rows.map(
      (r): CommentItem => ({
        id: asInt(r.id),
        body: r.body,
        createdAt: iso(r.created_at),
        author: {
          userId: r.user_id,
          handle: r.handle,
          displayName: r.display_name,
          hue: asInt(r.hue),
        },
      }),
    );
  });

export const createPost = createServerFn({ method: "POST" })
  .validator(
    z.object({
      body: z.string().min(1).max(1200),
      imageKey: z.string().nullable(),
      place: z.string().max(40),
    }),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const body = data.body.trim();
    if (!body) throw new Error("写一句再发射");
    const imageKey = isImageKey(data.imageKey) ? data.imageKey : null;
    const place = data.place.trim().slice(0, 40);
    const sql = await getSql();
    await ensureRow(sql, context.userId);
    const rows = await sql<{ id: number }>`
      insert into posts (user_id, body, image_key, place)
      values (${context.userId}, ${body}, ${imageKey}, ${place})
      returning id
    `;
    return { id: asInt(rows[0]?.id) };
  });

export const deletePost = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.number() }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureRow(sql, context.userId);
    await sql`
      delete from posts where id = ${data.id} and user_id = ${context.userId}
    `;
    return { ok: true };
  });

export const toggleLike = createServerFn({ method: "POST" })
  .validator(z.object({ postId: z.number() }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureRow(sql, context.userId);
    const existing = await sql<{ n: number }>`
      select 1 as n from likes
      where post_id = ${data.postId} and user_id = ${context.userId}
      limit 1
    `;
    if (existing.length) {
      await sql`
        delete from likes
        where post_id = ${data.postId} and user_id = ${context.userId}
      `;
      return { liked: false };
    }
    await sql`
      insert into likes (post_id, user_id)
      values (${data.postId}, ${context.userId})
      on conflict do nothing
    `;
    const owner = await sql<{ user_id: string }>`
      select user_id from posts where id = ${data.postId} limit 1
    `;
    if (owner[0] && owner[0].user_id !== context.userId) {
      await sql`
        insert into notifications (user_id, actor_id, type, post_id)
        values (${owner[0].user_id}, ${context.userId}, 'like', ${data.postId})
      `;
    }
    return { liked: true };
  });

export const addComment = createServerFn({ method: "POST" })
  .validator(
    z.object({
      postId: z.number(),
      body: z.string().min(1).max(280),
    }),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const body = data.body.trim();
    if (!body) throw new Error("写一句回应");
    const sql = await getSql();
    await ensureRow(sql, context.userId);
    const rows = await sql<{ id: number }>`
      insert into comments (post_id, user_id, body)
      values (${data.postId}, ${context.userId}, ${body})
      returning id
    `;
    const owner = await sql<{ user_id: string }>`
      select user_id from posts where id = ${data.postId} limit 1
    `;
    if (owner[0] && owner[0].user_id !== context.userId) {
      await sql`
        insert into notifications (user_id, actor_id, type, post_id)
        values (${owner[0].user_id}, ${context.userId}, 'comment', ${data.postId})
      `;
    }
    return { id: asInt(rows[0]?.id) };
  });

export const toggleFollow = createServerFn({ method: "POST" })
  .validator(z.object({ userId: z.string().min(1) }))
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    if (data.userId === context.userId) return { following: false };
    const sql = await getSql();
    await ensureRow(sql, context.userId);
    const existing = await sql<{ n: number }>`
      select 1 as n from follows
      where follower_id = ${context.userId} and followee_id = ${data.userId}
      limit 1
    `;
    if (existing.length) {
      await sql`
        delete from follows
        where follower_id = ${context.userId} and followee_id = ${data.userId}
      `;
      return { following: false };
    }
    await sql`
      insert into follows (follower_id, followee_id)
      values (${context.userId}, ${data.userId})
      on conflict do nothing
    `;
    await sql`
      insert into notifications (user_id, actor_id, type)
      values (${data.userId}, ${context.userId}, 'follow')
    `;
    return { following: true };
  });

export const getProfile = createServerFn({ method: "GET" })
  .validator(z.object({ handle: z.string().min(1).max(32) }))
  .middleware([optionalAuth])
  .handler(async ({ context, data }): Promise<ProfilePublic | null> => {
    const sql = await getSql();
    const rows = await sql<{
      user_id: string;
      handle: string;
      display_name: string;
      bio: string;
      location: string;
      hue: number;
      created_at: unknown;
    }>`
      select user_id, handle, display_name, bio, location, hue, created_at
      from profiles
      where handle = ${data.handle.toLowerCase()}
      limit 1
    `;
    const p = rows[0];
    if (!p) return null;
    const me = context.userId;
    const counts = await sql<{
      posts: unknown;
      followers: unknown;
      following: unknown;
    }>`
      select
        (select count(*)::int from posts where user_id = ${p.user_id}) as posts,
        (select count(*)::int from follows where followee_id = ${p.user_id}) as followers,
        (select count(*)::int from follows where follower_id = ${p.user_id}) as following
    `;
    let following = false;
    if (me && me !== p.user_id) {
      const f = await sql<{ n: number }>`
        select 1 as n from follows
        where follower_id = ${me} and followee_id = ${p.user_id}
        limit 1
      `;
      following = f.length > 0;
    }
    return {
      userId: p.user_id,
      handle: p.handle,
      displayName: p.display_name,
      bio: p.bio,
      location: p.location,
      hue: asInt(p.hue),
      createdAt: iso(p.created_at),
      postCount: asInt(counts[0]?.posts),
      followerCount: asInt(counts[0]?.followers),
      followingCount: asInt(counts[0]?.following),
      isMe: me === p.user_id,
      following,
    };
  });

export const listUserPosts = createServerFn({ method: "GET" })
  .validator(z.object({ userId: z.string().min(1) }))
  .middleware([optionalAuth])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const likedParam = context.userId ?? "__none__";
    const rows = await sql<PostRow>`
      select
        p.id,
        p.body,
        p.image_key,
        p.place,
        p.created_at,
        pr.user_id as author_id,
        pr.handle,
        pr.display_name,
        pr.hue,
        (select count(*)::int from likes l where l.post_id = p.id) as like_count,
        (select count(*)::int from comments c where c.post_id = p.id) as comment_count,
        exists(select 1 from likes lx where lx.post_id = p.id and lx.user_id = ${likedParam}) as liked
      from posts p
      join profiles pr on pr.user_id = p.user_id
      where p.user_id = ${data.userId}
      order by p.created_at desc
      limit 40
    `;
    return rows.map(mapPost);
  });

export const updateProfile = createServerFn({ method: "POST" })
  .validator(
    z.object({
      displayName: z.string().min(1).max(24),
      bio: z.string().max(120),
      location: z.string().max(24),
    }),
  )
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    await ensureRow(sql, context.userId);
    await sql`
      update profiles
      set
        display_name = ${data.displayName.trim().slice(0, 24)},
        bio = ${data.bio.trim().slice(0, 120)},
        location = ${data.location.trim().slice(0, 24)}
      where user_id = ${context.userId}
    `;
    return { ok: true };
  });

export const listPeople = createServerFn({ method: "GET" })
  .validator(
    z.object({
      q: z.string().max(40).optional(),
    }),
  )
  .middleware([optionalAuth])
  .handler(async ({ context, data }) => {
    const sql = await getSql();
    const me = context.userId ?? "__none__";
    const q = data.q?.trim() ?? "";
    const like = q ? `%${q}%` : "%";
    const rows = await sql<{
      user_id: string;
      handle: string;
      display_name: string;
      bio: string;
      location: string;
      hue: number;
      follower_count: unknown;
      following: unknown;
    }>`
      select
        pr.user_id,
        pr.handle,
        pr.display_name,
        pr.bio,
        pr.location,
        pr.hue,
        (select count(*)::int from follows f where f.followee_id = pr.user_id) as follower_count,
        exists(
          select 1 from follows x
          where x.follower_id = ${me} and x.followee_id = pr.user_id
        ) as following
      from profiles pr
      where (
        ${q} = ''
        or pr.handle ilike ${like}
        or pr.display_name ilike ${like}
        or pr.location ilike ${like}
      )
      order by follower_count desc, pr.created_at asc
      limit 24
    `;
    return rows.map(
      (r): PersonCard => ({
        userId: r.user_id,
        handle: r.handle,
        displayName: r.display_name,
        bio: r.bio,
        location: r.location,
        hue: asInt(r.hue),
        followerCount: asInt(r.follower_count),
        following: asBool(r.following),
      }),
    );
  });

export const listNotifications = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ensureRow(sql, context.userId);
    const rows = await sql<{
      id: number;
      type: string;
      read: unknown;
      created_at: unknown;
      post_id: number | null;
      user_id: string;
      handle: string;
      display_name: string;
      hue: number;
    }>`
      select
        n.id, n.type, n.read, n.created_at, n.post_id,
        pr.user_id, pr.handle, pr.display_name, pr.hue
      from notifications n
      join profiles pr on pr.user_id = n.actor_id
      where n.user_id = ${context.userId}
      order by n.created_at desc
      limit 40
    `;
    return rows.map((r): NoticeItem => {
      const type =
        r.type === "comment" || r.type === "follow" || r.type === "like"
          ? r.type
          : "like";
      return {
        id: asInt(r.id),
        type,
        read: asBool(r.read),
        createdAt: iso(r.created_at),
        postId: r.post_id == null ? null : asInt(r.post_id),
        actor: {
          userId: r.user_id,
          handle: r.handle,
          displayName: r.display_name,
          hue: asInt(r.hue),
        },
      };
    });
  });

export const unreadCount = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ensureRow(sql, context.userId);
    const rows = await sql<{ n: unknown }>`
      select count(*)::int as n
      from notifications
      where user_id = ${context.userId} and read = false
    `;
    return asInt(rows[0]?.n);
  });

export const markRead = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ensureRow(sql, context.userId);
    await sql`
      update notifications set read = true
      where user_id = ${context.userId} and read = false
    `;
    return { ok: true };
  });

export const myProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await ensureRow(sql, context.userId);
    const rows = await sql<{ handle: string; display_name: string }>`
      select handle, display_name from profiles
      where user_id = ${context.userId}
      limit 1
    `;
    return rows[0]
      ? { handle: rows[0].handle, displayName: rows[0].display_name }
      : null;
  });

export const clusterStats = createServerFn({ method: "GET" }).handler(
  async () => {
    const sql = await getSql();
    const rows = await sql<{ nodes: unknown; sparks: unknown; links: unknown }>`
      select
        (select count(*)::int from profiles) as nodes,
        (select count(*)::int from posts) as sparks,
        (select count(*)::int from comments) as links
    `;
    return {
      nodes: asInt(rows[0]?.nodes),
      sparks: asInt(rows[0]?.sparks),
      links: asInt(rows[0]?.links),
    };
  },
);

export type { Author };
