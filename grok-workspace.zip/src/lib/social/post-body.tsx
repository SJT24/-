type Part =
  | { type: "text"; value: string }
  | { type: "code"; lang: string; value: string };

function splitFences(raw: string): Part[] {
  const parts: Part[] = [];
  const re = /```(\w*)\n([\s\S]*?)```/g;
  let last = 0;
  let match: RegExpExecArray | null;
  while ((match = re.exec(raw))) {
    if (match.index > last) {
      parts.push({ type: "text", value: raw.slice(last, match.index) });
    }
    parts.push({
      type: "code",
      lang: match[1] ?? "",
      value: match[2].replace(/\n$/, ""),
    });
    last = match.index + match[0].length;
  }
  if (last < raw.length) parts.push({ type: "text", value: raw.slice(last) });
  return parts.filter((p) => p.value.trim().length > 0);
}

export function PostBody({ text }: { text: string }) {
  const parts = splitFences(text);
  return (
    <div className="space-y-3">
      {parts.map((part, i) =>
        part.type === "code" ? (
          <pre
            key={i}
            className="overflow-x-auto rounded-lg border border-line bg-bg p-3 font-mono text-xs leading-relaxed text-neon"
          >
            {part.lang ? (
              <div className="mb-2 font-mono text-xs uppercase tracking-widest text-faint">
                {part.lang}
              </div>
            ) : null}
            <code>{part.value}</code>
          </pre>
        ) : (
          <p
            key={i}
            className="whitespace-pre-wrap text-sm leading-relaxed text-fg"
          >
            {part.value.trim()}
          </p>
        ),
      )}
    </div>
  );
}
